import {
    FlaskConical,
    Gauge,
    KeyRound,
    PackageSearch,
    Syringe,
    UsersRound,
} from "lucide-react";

import EnterpriseShell from "../components/common/EnterpriseShell";

const adminMenu = [
    { to: "/admin", label: "Trung tâm quản trị", icon: Gauge, end: true },
    { to: "/admin/users", label: "Tài khoản & phân quyền", icon: UsersRound },
    { to: "/admin/vaccines", label: "Danh mục vaccine", icon: Syringe },
    { to: "/admin/batches", label: "Theo dõi lô vaccine", icon: FlaskConical },
    { to: "/admin/trace", label: "Truy vết hệ thống", icon: PackageSearch },
    { to: "/admin/change-password", label: "Bảo mật tài khoản", icon: KeyRound },
];

function AdminLayout() {
    return <EnterpriseShell role="admin" menuItems={adminMenu} />;
}

export default AdminLayout;
