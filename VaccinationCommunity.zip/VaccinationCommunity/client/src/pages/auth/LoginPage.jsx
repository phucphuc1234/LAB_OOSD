import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "motion/react";
import {
    ArrowRight,
    LockKeyhole,
    ShieldCheck,
    Sparkles,
    UserRound,
} from "lucide-react";

import authService from "../../services/authService";
import MedicalOrbScene from "../../components/visuals/MedicalOrbScene";
import ThreeUiAmbient from "../../components/visuals/ThreeUiAmbient";

function LoginPage() {
    const navigate = useNavigate();
    const [tenDangNhap, setTenDangNhap] = useState("");
    const [matKhau, setMatKhau] = useState("");
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");
        setLoading(true);

        try {
            const response = await authService.login(tenDangNhap, matKhau);
            authService.saveLogin(response.token, response.user);

            const role = response.user.tenVaiTro;
            if (role === "Người dân") navigate("/citizen");
            else if (role === "Nhân viên") navigate("/staff");
            else if (role === "Quản trị viên") navigate("/admin");
            else setError("Vai trò tài khoản không hợp lệ.");
        } catch (err) {
            setError(err.response?.data?.message || "Đăng nhập thất bại.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="auth-enterprise-page">
            <div className="auth-ambient-layer pointer-events-none absolute inset-0" aria-hidden="true">
                <div className="auth-grid" />
                <div className="auth-glow auth-glow-a" />
                <div className="auth-glow auth-glow-b" />
                <ThreeUiAmbient />
            </div>

            <div className="auth-enterprise-shell">
                <motion.section
                    className="auth-visual-panel"
                    initial={{ opacity: 0, x: -28 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.62, ease: [0.22, 1, 0.36, 1] }}
                >
                    <div className="auth-brand-row">
                        <span className="auth-brand-mark"><ShieldCheck size={21} /></span>
                        <div>
                            <strong>VaxCommunity</strong>
                            <small>Cổng theo dõi tiêm chủng cộng đồng</small>
                        </div>
                    </div>

                    <div className="auth-visual-copy">
                        <div className="auth-kicker"><Sparkles size={15} /> NỀN TẢNG Y TẾ SỐ 2026</div>
                        <h1>Tiêm chủng thông minh.<br />Sức khỏe chủ động.</h1>
                        <p>
                            Một không gian số an toàn để theo dõi lịch tiêm, lịch sử,
                            chống chỉ định và thông báo sức khỏe theo thời gian thực.
                        </p>

                        <div className="auth-metrics">
                            <div><strong>24/7</strong><span>Theo dõi lịch</span></div>
                            <div><strong>01</strong><span>Hồ sơ tập trung</span></div>
                            <div><strong>3 ngày</strong><span>Nhắc lịch tự động</span></div>
                        </div>
                    </div>

                    <MedicalOrbScene className="auth-orb-scene" />

                    <div className="auth-security-note">
                        <ShieldCheck size={17} />
                        <span>Dữ liệu sức khỏe được bảo vệ trong luồng xác thực của hệ thống.</span>
                    </div>
                </motion.section>

                <motion.section
                    className="auth-form-panel"
                    initial={{ opacity: 0, y: 18, scale: 0.985 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    transition={{ duration: 0.52, delay: 0.08, ease: [0.22, 1, 0.36, 1] }}
                >
                    <div className="auth-form-header">
                        <span className="auth-form-eyebrow">TRUY CẬP HỆ THỐNG</span>
                        <h2>Chào mừng trở lại</h2>
                        <p>Đăng nhập để tiếp tục quản lý thông tin tiêm chủng.</p>
                    </div>

                    {error && (
                        <motion.div
                            className="alert alert-danger auth-alert"
                            initial={{ opacity: 0, y: -5 }}
                            animate={{ opacity: 1, y: 0 }}
                        >
                            {error}
                        </motion.div>
                    )}

                    <form onSubmit={handleSubmit} className="auth-form">
                        <label className="auth-field">
                            <span>Tên đăng nhập</span>
                            <div className="auth-input-wrap">
                                <UserRound size={18} />
                                <input
                                    type="text"
                                    value={tenDangNhap}
                                    onChange={(e) => setTenDangNhap(e.target.value)}
                                    placeholder="Nhập tên đăng nhập"
                                    autoComplete="username"
                                    required
                                />
                            </div>
                        </label>

                        <label className="auth-field">
                            <span>Mật khẩu</span>
                            <div className="auth-input-wrap">
                                <LockKeyhole size={18} />
                                <input
                                    type="password"
                                    value={matKhau}
                                    onChange={(e) => setMatKhau(e.target.value)}
                                    placeholder="Nhập mật khẩu"
                                    autoComplete="current-password"
                                    required
                                />
                            </div>
                        </label>

                        <motion.button
                            type="submit"
                            className="auth-primary-button"
                            disabled={loading}
                            whileHover={!loading ? { y: -2 } : undefined}
                            whileTap={!loading ? { scale: 0.985 } : undefined}
                        >
                            <span>{loading ? "Đang xác thực..." : "Đăng nhập an toàn"}</span>
                            {!loading && <ArrowRight size={18} />}
                        </motion.button>
                    </form>

                    <div className="auth-register-link">
                        <span>Chưa có tài khoản?</span>
                        <Link to="/register">Đăng ký ngay</Link>
                    </div>

                    <div className="auth-role-hint">
                        <span>Người dân</span>
                        <span>Nhân viên</span>
                        <span>Quản trị viên</span>
                    </div>
                </motion.section>
            </div>
        </div>
    );
}

export default LoginPage;
