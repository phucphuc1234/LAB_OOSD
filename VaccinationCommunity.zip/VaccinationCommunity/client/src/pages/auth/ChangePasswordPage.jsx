import { useState } from "react";
import { useNavigate } from "react-router-dom";

import authService
    from "../../services/authService";


function ChangePasswordPage() {

    const navigate = useNavigate();

    const [formData, setFormData] =
        useState({
            matKhauHienTai: "",
            matKhauMoi: "",
            xacNhanMatKhauMoi: "",
        });

    const [showPassword, setShowPassword] =
        useState(false);

    const [loading, setLoading] =
        useState(false);

    const [error, setError] =
        useState("");

    const [message, setMessage] =
        useState("");


    const handleChange = (e) => {

        const { name, value } =
            e.target;

        setFormData((prev) => ({
            ...prev,
            [name]: value,
        }));
    };


    const handleSubmit = async (e) => {

        e.preventDefault();

        setError("");
        setMessage("");


        if (
            formData.matKhauMoi !==
            formData.xacNhanMatKhauMoi
        ) {
            setError(
                "Xác nhận mật khẩu mới không khớp."
            );

            return;
        }


        if (formData.matKhauMoi.length < 6) {
            setError(
                "Mật khẩu mới phải có ít nhất 6 ký tự."
            );

            return;
        }


        try {

            setLoading(true);

            const response =
                await authService
                    .changePassword({
                        matKhauHienTai:
                            formData.matKhauHienTai,

                        matKhauMoi:
                            formData.matKhauMoi,
                    });


            setMessage(
                response.message ||
                "Đổi mật khẩu thành công."
            );


            setTimeout(() => {

                authService.logout();

                navigate(
                    "/login",
                    { replace: true }
                );

            }, 1500);


        } catch (err) {

            setError(
                err.response?.data?.message ||
                "Đổi mật khẩu thất bại."
            );

        } finally {

            setLoading(false);
        }
    };


    return (
        <div>

            <div className="mb-4">

                <h2>
                    Đổi mật khẩu
                </h2>

                <p className="text-muted">
                    Cập nhật mật khẩu đăng nhập
                    của tài khoản
                </p>

            </div>


            {message && (
                <div className="alert alert-success">
                    {message}
                </div>
            )}


            {error && (
                <div className="alert alert-danger">
                    {error}
                </div>
            )}


            <div
                className="card shadow-sm"
                style={{
                    maxWidth: "650px"
                }}
            >

                <div className="card-body">

                    <form onSubmit={handleSubmit}>


                        <div className="mb-3">

                            <label className="form-label">
                                Mật khẩu hiện tại
                            </label>

                            <input
                                type={
                                    showPassword
                                        ? "text"
                                        : "password"
                                }
                                className="form-control"
                                name="matKhauHienTai"
                                value={
                                    formData.matKhauHienTai
                                }
                                onChange={handleChange}
                                required
                            />

                        </div>


                        <div className="mb-3">

                            <label className="form-label">
                                Mật khẩu mới
                            </label>

                            <input
                                type={
                                    showPassword
                                        ? "text"
                                        : "password"
                                }
                                className="form-control"
                                name="matKhauMoi"
                                value={
                                    formData.matKhauMoi
                                }
                                onChange={handleChange}
                                minLength="6"
                                required
                            />

                        </div>


                        <div className="mb-3">

                            <label className="form-label">
                                Xác nhận mật khẩu mới
                            </label>

                            <input
                                type={
                                    showPassword
                                        ? "text"
                                        : "password"
                                }
                                className="form-control"
                                name="xacNhanMatKhauMoi"
                                value={
                                    formData.xacNhanMatKhauMoi
                                }
                                onChange={handleChange}
                                minLength="6"
                                required
                            />

                        </div>


                        <div className="form-check mb-4">

                            <input
                                className="form-check-input"
                                type="checkbox"
                                id="showPassword"
                                checked={showPassword}
                                onChange={(e) =>
                                    setShowPassword(
                                        e.target.checked
                                    )
                                }
                            />

                            <label
                                className="form-check-label"
                                htmlFor="showPassword"
                            >
                                Hiển thị mật khẩu
                            </label>

                        </div>


                        <button
                            type="submit"
                            className="btn btn-primary"
                            disabled={loading}
                        >
                            {loading
                                ? "Đang đổi..."
                                : "Đổi mật khẩu"}
                        </button>

                    </form>

                </div>

            </div>

        </div>
    );
}

export default ChangePasswordPage;