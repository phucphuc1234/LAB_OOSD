import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import authService from "../../services/authService";


function RegisterPage() {

    const navigate = useNavigate();

    const [formData, setFormData] =
        useState({
            tenDangNhap: "",
            matKhau: "",
            xacNhanMatKhau: "",
            hoTen: "",
            ngaySinh: "",
            gioiTinh: "",
            cccd: "",
            soBHYT: "",
            soDienThoai: "",
            email: "",
            diaChi: "",
            phuongXa: "",
            quanHuyen: "",
            tinhThanh: "",
        });

    const [loading, setLoading] =
        useState(false);

    const [error, setError] =
        useState("");

    const [message, setMessage] =
        useState("");


    const handleChange = (e) => {

        const { name, value } =
            e.target;

        setFormData((prev) => ({
            ...prev,
            [name]: value,
        }));
    };


    const handleSubmit = async (e) => {
        e.preventDefault();

        setError("");
        setMessage("");

        // Kiểm tra tên đăng nhập
        const usernameRegex = /^[A-Za-z0-9_]+$/;

        if (
            !usernameRegex.test(
                formData.tenDangNhap
            )
        ) {
            setError(
                "Tên đăng nhập không đúng định dạng. Vui lòng nhập chữ không dấu, số hoặc dấu gạch dưới (_), không được có khoảng trắng."
            );

            return;
        }

        // Kiểm tra xác nhận mật khẩu
        if (
            formData.matKhau !==
            formData.xacNhanMatKhau
        ) {
            setError(
                "Xác nhận mật khẩu không khớp."
            );

            return;
        }

        // Kiểm tra độ dài mật khẩu
        if (formData.matKhau.length < 6) {
            setError(
                "Mật khẩu phải có ít nhất 6 ký tự."
            );

            return;
        }

        try {
            setLoading(true);

            // Gọi API đăng ký
            await authService.register({
                tenDangNhap:
                    formData.tenDangNhap,

                matKhau:
                    formData.matKhau,

                hoTen:
                    formData.hoTen,

                ngaySinh:
                    formData.ngaySinh,

                gioiTinh:
                    formData.gioiTinh,

                cccd:
                    formData.cccd || null,

                soBHYT:
                    formData.soBHYT || null,

                soDienThoai:
                    formData.soDienThoai || null,

                email:
                    formData.email || null,

                diaChi:
                    formData.diaChi || null,

                phuongXa:
                    formData.phuongXa || null,

                quanHuyen:
                    formData.quanHuyen || null,

                tinhThanh:
                    formData.tinhThanh || null,
            });

            // Đăng ký thành công
            setMessage(
                "Đăng ký tài khoản thành công! Đang chuyển đến trang đăng nhập..."
            );

            // Sau 2 giây quay về đăng nhập
            setTimeout(() => {
                navigate(
                    "/login",
                    { replace: true }
                );
            }, 2000);

        } catch (err) {

            setMessage("");

            setError(
                err.response?.data?.message ||
                "Đăng ký tài khoản thất bại."
            );

        } finally {
            setLoading(false);
        }
    };


    return (
        <div
            className="container py-5 auth-register-page"
            style={{
                maxWidth: "850px"
            }}
        >

            <div className="card shadow auth-register-card">

                <div className="card-body p-4 p-lg-5">

                    <div className="text-center mb-4">

                        <h2>
                            Đăng ký tài khoản
                        </h2>

                        <p className="text-muted">
                            Cổng theo dõi tiêm chủng cộng đồng
                        </p>

                    </div>


                    {message && (
                        <div className="alert alert-success">
                            {message}
                        </div>
                    )}


                    {error && (
                        <div className="alert alert-danger">
                            {error}
                        </div>
                    )}


                    <form onSubmit={handleSubmit}>

                        <h5 className="mb-3">
                            Thông tin tài khoản
                        </h5>


                        <div className="row">

                            <div className="col-md-6 mb-3">

                                <label className="form-label">
                                    Tên đăng nhập
                                </label>
                                <input
                                    type="text"
                                    className="form-control"
                                    name="tenDangNhap"
                                    value={formData.tenDangNhap}
                                    onChange={handleChange}
                                    placeholder="Ví dụ: phantrongphuc"
                                    pattern="[A-Za-z0-9_]+"
                                    title="Tên đăng nhập chỉ được chứa chữ không dấu, số và dấu gạch dưới (_)"
                                    required
                                />

                                <div className="form-text">
                                    Tên đăng nhập không dấu, không khoảng trắng.
                                    Ví dụ: phantrongphuc
                                </div>

                            </div>


                            <div className="col-md-6 mb-3">

                                <label className="form-label">
                                    Email
                                </label>

                                <input
                                    type="email"
                                    className="form-control"
                                    name="email"
                                    value={
                                        formData.email
                                    }
                                    onChange={handleChange}
                                />

                            </div>


                            <div className="col-md-6 mb-3">

                                <label className="form-label">
                                    Mật khẩu
                                </label>

                                <input
                                    type="password"
                                    className="form-control"
                                    name="matKhau"
                                    value={
                                        formData.matKhau
                                    }
                                    onChange={handleChange}
                                    minLength="6"
                                    required
                                />

                            </div>


                            <div className="col-md-6 mb-3">

                                <label className="form-label">
                                    Xác nhận mật khẩu
                                </label>

                                <input
                                    type="password"
                                    className="form-control"
                                    name="xacNhanMatKhau"
                                    value={
                                        formData.xacNhanMatKhau
                                    }
                                    onChange={handleChange}
                                    minLength="6"
                                    required
                                />

                            </div>

                        </div>


                        <hr />


                        <h5 className="mb-3">
                            Thông tin người dân
                        </h5>


                        <div className="row">

                            <div className="col-md-6 mb-3">

                                <label className="form-label">
                                    Họ và tên
                                </label>

                                <input
                                    type="text"
                                    className="form-control"
                                    name="hoTen"
                                    value={
                                        formData.hoTen
                                    }
                                    onChange={handleChange}
                                    required
                                />

                            </div>


                            <div className="col-md-3 mb-3">

                                <label className="form-label">
                                    Ngày sinh
                                </label>

                                <input
                                    type="date"
                                    className="form-control"
                                    name="ngaySinh"
                                    value={
                                        formData.ngaySinh
                                    }
                                    onChange={handleChange}
                                    required
                                />

                            </div>


                            <div className="col-md-3 mb-3">

                                <label className="form-label">
                                    Giới tính
                                </label>

                                <select
                                    className="form-select"
                                    name="gioiTinh"
                                    value={
                                        formData.gioiTinh
                                    }
                                    onChange={handleChange}
                                    required
                                >

                                    <option value="">
                                        -- Chọn --
                                    </option>

                                    <option value="Nam">
                                        Nam
                                    </option>

                                    <option value="Nữ">
                                        Nữ
                                    </option>

                                    <option value="Khác">
                                        Khác
                                    </option>

                                </select>

                            </div>


                            <div className="col-md-6 mb-3">

                                <label className="form-label">
                                    CCCD
                                </label>

                                <input
                                    type="text"
                                    className="form-control"
                                    name="cccd"
                                    value={
                                        formData.cccd
                                    }
                                    onChange={handleChange}
                                />

                            </div>


                            <div className="col-md-6 mb-3">

                                <label className="form-label">
                                    Số BHYT
                                </label>

                                <input
                                    type="text"
                                    className="form-control"
                                    name="soBHYT"
                                    value={
                                        formData.soBHYT
                                    }
                                    onChange={handleChange}
                                />

                            </div>


                            <div className="col-md-6 mb-3">

                                <label className="form-label">
                                    Số điện thoại
                                </label>

                                <input
                                    type="text"
                                    className="form-control"
                                    name="soDienThoai"
                                    value={
                                        formData.soDienThoai
                                    }
                                    onChange={handleChange}
                                />

                            </div>


                            <div className="col-md-6 mb-3">

                                <label className="form-label">
                                    Tỉnh / Thành phố
                                </label>

                                <input
                                    type="text"
                                    className="form-control"
                                    name="tinhThanh"
                                    value={
                                        formData.tinhThanh
                                    }
                                    onChange={handleChange}
                                />

                            </div>


                            <div className="col-md-6 mb-3">

                                <label className="form-label">
                                    Quận / Huyện
                                </label>

                                <input
                                    type="text"
                                    className="form-control"
                                    name="quanHuyen"
                                    value={
                                        formData.quanHuyen
                                    }
                                    onChange={handleChange}
                                />

                            </div>


                            <div className="col-md-6 mb-3">

                                <label className="form-label">
                                    Phường / Xã
                                </label>

                                <input
                                    type="text"
                                    className="form-control"
                                    name="phuongXa"
                                    value={
                                        formData.phuongXa
                                    }
                                    onChange={handleChange}
                                />

                            </div>


                            <div className="col-12 mb-3">

                                <label className="form-label">
                                    Địa chỉ
                                </label>

                                <input
                                    type="text"
                                    className="form-control"
                                    name="diaChi"
                                    value={
                                        formData.diaChi
                                    }
                                    onChange={handleChange}
                                />

                            </div>

                        </div>


                        <button
                            type="submit"
                            className="btn btn-primary w-100"
                            disabled={loading}
                        >
                            {loading
                                ? "Đang đăng ký..."
                                : "Đăng ký tài khoản"}
                        </button>


                        <div className="text-center mt-3">

                            Đã có tài khoản?
                            {" "}

                            <Link to="/login">
                                Đăng nhập
                            </Link>

                        </div>

                    </form>

                </div>

            </div>

        </div>
    );
}

export default RegisterPage;