import {
    useEffect,
    useState
} from "react";

import {
    Link
} from "react-router-dom";

import userService
    from "../../services/userService";

import vaccineService
    from "../../services/vaccineService";

import batchService
    from "../../services/batchService";


function AdminHome() {

    const [users, setUsers] =
        useState([]);

    const [vaccines, setVaccines] =
        useState([]);

    const [batches, setBatches] =
        useState([]);

    const [loading, setLoading] =
        useState(true);


    useEffect(() => {

        const loadDashboard =
            async () => {

                try {

                    const [
                        userRes,
                        vaccineRes,
                        batchRes
                    ] = await Promise.all([

                        userService
                            .getAllUsers(),

                        vaccineService
                            .getAllVaccines(),

                        batchService
                            .getAllBatches()

                    ]);


                    setUsers(
                        userRes.data || []
                    );

                    setVaccines(
                        vaccineRes.data || []
                    );

                    setBatches(
                        batchRes.data || []
                    );

                } catch (error) {

                    console.error(
                        "Lỗi tải Admin Dashboard:",
                        error
                    );

                } finally {

                    setLoading(false);
                }
            };


        loadDashboard();

    }, []);


    const getUserStatus = (item) => {

        return String(
            item.TrangThai ??
            item.trangThai ??
            ""
        )
            .trim()
            .toLowerCase();
    };


    const activeUsers =
        users.filter((item) => {

            const status =
                getUserStatus(item);

            return (
                status === "hoạt động" ||
                status === "hoat dong" ||
                status === "active" ||
                status === "1" ||
                status === "true"
            );
        });


    const lockedUsers =
        users.filter((item) => {

            const status =
                getUserStatus(item);

            return (
                status === "đã khóa" ||
                status === "da khoa" ||
                status === "khóa" ||
                status === "locked" ||
                status === "0" ||
                status === "false"
            );
        });


    const activeBatches =
        batches.filter(
            (item) =>
                item.TrangThai ===
                "Đang sử dụng"
        );


    const citizenCount =
        users.filter(
            (item) =>
                item.TenVaiTro ===
                "Người dân"
        ).length;


    const staffCount =
        users.filter(
            (item) =>
                item.TenVaiTro ===
                "Nhân viên"
        ).length;


    const adminCount =
        users.filter(
            (item) =>
                item.TenVaiTro ===
                "Quản trị viên"
        ).length;


    if (loading) {

        return (
            <div className="text-center py-5">
                Đang tải dữ liệu...
            </div>
        );
    }


    return (

        <div className="admin-home">


            {/* BANNER */}

            <section className="admin-hero mb-4">

                <div className="admin-hero-content">

                    <div className="admin-hero-small">
                        QUẢN TRỊ HỆ THỐNG
                    </div>


                    <h1>
                        Trung tâm quản trị
                    </h1>


                    <p>
                        Quản lý tài khoản,
                        phân quyền, vaccine,
                        lô vaccine và giám sát
                        hoạt động của hệ thống.
                    </p>


                    <div
                        className="
                            d-flex
                            gap-2
                            flex-wrap
                        "
                    >

                        <Link
                            to="/admin/users"
                            className="
                                btn
                                btn-light
                                fw-semibold
                            "
                        >
                            Quản lý tài khoản
                        </Link>


                        <Link
                            to="/admin/trace"
                            className="
                                btn
                                btn-outline-light
                            "
                        >
                            Truy vết vaccine
                        </Link>

                    </div>

                </div>


                <div className="admin-hero-icon">
                    ⚙️
                </div>

            </section>


            {/* THỐNG KÊ */}

            <div className="row g-3 mb-4">

                <AdminStatCard
                    icon="👥"
                    title="Tổng tài khoản"
                    value={users.length}
                    className="bg-primary-subtle"
                />


                <AdminStatCard
                    icon="✅"
                    title="Đang hoạt động"
                    value={activeUsers.length}
                    className="bg-success-subtle"
                />


                <AdminStatCard
                    icon="💉"
                    title="Vaccine"
                    value={vaccines.length}
                    className="bg-info-subtle"
                />


                <AdminStatCard
                    icon="📦"
                    title="Lô đang sử dụng"
                    value={activeBatches.length}
                    className="bg-warning-subtle"
                />

            </div>


            {/* THÔNG TIN CHÍNH */}

            <div className="row g-4 mb-4">


                {/* PHÂN BỔ TÀI KHOẢN */}

                <div className="col-lg-7">

                    <div
                        className="
                            card
                            shadow-sm
                            h-100
                        "
                    >

                        <div className="card-header">

                            <strong>
                                👥 Phân bổ tài khoản
                            </strong>

                        </div>


                        <div className="card-body">

                            <RoleInfo
                                title="Người dân"
                                value={citizenCount}
                                percent={
                                    users.length
                                        ? Math.round(
                                            citizenCount /
                                            users.length *
                                            100
                                        )
                                        : 0
                                }
                                className="bg-primary"
                            />


                            <RoleInfo
                                title="Nhân viên"
                                value={staffCount}
                                percent={
                                    users.length
                                        ? Math.round(
                                            staffCount /
                                            users.length *
                                            100
                                        )
                                        : 0
                                }
                                className="bg-success"
                            />


                            <RoleInfo
                                title="Quản trị viên"
                                value={adminCount}
                                percent={
                                    users.length
                                        ? Math.round(
                                            adminCount /
                                            users.length *
                                            100
                                        )
                                        : 0
                                }
                                className="bg-dark"
                            />


                            <div className="mt-4">

                                <Link
                                    to="/admin/users"
                                    className="
                                        btn
                                        btn-dark
                                    "
                                >
                                    Xem danh sách tài khoản
                                </Link>

                            </div>

                        </div>

                    </div>

                </div>


                {/* TRẠNG THÁI HỆ THỐNG */}

                <div className="col-lg-5">

                    <div
                        className="
                            card
                            shadow-sm
                            h-100
                        "
                    >

                        <div className="card-header">

                            <strong>
                                📊 Trạng thái hệ thống
                            </strong>

                        </div>


                        <div className="card-body">

                            <SystemInfo
                                label="Tài khoản hoạt động"
                                value={
                                    activeUsers.length
                                }
                                status="Tốt"
                            />


                            <SystemInfo
                                label="Tài khoản khóa"
                                value={
                                    lockedUsers.length
                                }
                                status={
                                    lockedUsers.length === 0
                                        ? "Tốt"
                                        : "Cần kiểm tra"
                                }
                            />


                            <SystemInfo
                                label="Vaccine"
                                value={
                                    vaccines.length
                                }
                                status="Đang quản lý"
                            />


                            <SystemInfo
                                label="Lô vaccine"
                                value={
                                    batches.length
                                }
                                status="Đang quản lý"
                            />

                        </div>

                    </div>

                </div>

            </div>


            {/* TRUY CẬP NHANH */}

            <section className="mb-4">

                <h4 className="mb-3">
                    Truy cập nhanh
                </h4>


                <div className="row g-3">

                    <AdminQuickCard
                        icon="👥"
                        title="Tài khoản"
                        description="Quản lý và khóa mở tài khoản"
                        link="/admin/users"
                    />


                    <AdminQuickCard
                        icon="🔐"
                        title="Phân quyền"
                        description="Thay đổi vai trò người dùng"
                        link="/admin/users"
                    />


                    <AdminQuickCard
                        icon="💉"
                        title="Vaccine"
                        description="Quản lý danh mục vaccine"
                        link="/admin/vaccines"
                    />


                    <AdminQuickCard
                        icon="📦"
                        title="Lô vaccine"
                        description="Quản lý thông tin lô vaccine"
                        link="/admin/batches"
                    />


                    <AdminQuickCard
                        icon="🔎"
                        title="Truy vết"
                        description="Truy vết theo lô hoặc mũi tiêm"
                        link="/admin/trace"
                    />


                    <AdminQuickCard
                        icon="🔑"
                        title="Đổi mật khẩu"
                        description="Cập nhật mật khẩu quản trị"
                        link="/admin/change-password"
                    />

                </div>

            </section>


            {/* NHIỆM VỤ ADMIN */}

            <div
                className="
                    card
                    shadow-sm
                    mb-4
                "
            >

                <div className="card-body">

                    <h4>
                        ⚙️ Nhiệm vụ quản trị hệ thống
                    </h4>


                    <div
                        className="
                            row
                            g-3
                            mt-1
                        "
                    >

                        <AdminGuide
                            number="01"
                            title="Quản lý tài khoản"
                            text="Theo dõi trạng thái và thông tin tài khoản người dùng."
                        />


                        <AdminGuide
                            number="02"
                            title="Phân quyền"
                            text="Thiết lập vai trò phù hợp cho từng tài khoản."
                        />


                        <AdminGuide
                            number="03"
                            title="Quản lý vaccine"
                            text="Theo dõi vaccine và các lô vaccine trong hệ thống."
                        />


                        <AdminGuide
                            number="04"
                            title="Giám sát truy vết"
                            text="Hỗ trợ tra cứu nguồn gốc và lịch sử sử dụng vaccine."
                        />

                    </div>

                </div>

            </div>

        </div>
    );
}


function AdminStatCard({
    icon,
    title,
    value,
    className
}) {

    return (

        <div className="col-md-6 col-xl-3">

            <div className="admin-stat-card">

                <div
                    className={
                        `admin-stat-icon ${className}`
                    }
                >
                    {icon}
                </div>


                <div>

                    <div className="admin-stat-label">
                        {title}
                    </div>

                    <div className="admin-stat-number">
                        {value}
                    </div>

                </div>

            </div>

        </div>
    );
}


function RoleInfo({
    title,
    value,
    percent,
    className
}) {

    return (

        <div className="admin-role-item">

            <div
                className="
                    d-flex
                    justify-content-between
                    mb-2
                "
            >

                <span>
                    {title}
                </span>

                <strong>
                    {value}
                </strong>

            </div>


            <div className="progress">

                <div
                    className={
                        `progress-bar ${className}`
                    }
                    style={{
                        width:
                            `${percent}%`
                    }}
                >
                    {percent}%
                </div>

            </div>

        </div>
    );
}


function SystemInfo({
    label,
    value,
    status
}) {

    return (

        <div className="admin-system-info">

            <div>

                <div className="text-muted small">
                    {label}
                </div>

                <strong>
                    {value}
                </strong>

            </div>


            <span
                className={
                    status === "Tốt"
                        ? "badge bg-success"
                        : "badge bg-secondary"
                }
            >
                {status}
            </span>

        </div>
    );
}


function AdminQuickCard({
    icon,
    title,
    description,
    link
}) {

    return (

        <div className="col-md-6 col-xl-4">

            <Link
                to={link}
                className="
                    admin-quick-card
                    text-decoration-none
                "
            >

                <div className="admin-quick-icon">
                    {icon}
                </div>


                <div>

                    <strong>
                        {title}
                    </strong>

                    <p>
                        {description}
                    </p>

                </div>

            </Link>

        </div>
    );
}


function AdminGuide({
    number,
    title,
    text
}) {

    return (

        <div className="col-md-6 col-xl-3">

            <div className="admin-guide">

                <div className="admin-guide-number">
                    {number}
                </div>


                <div>

                    <strong>
                        {title}
                    </strong>

                    <p>
                        {text}
                    </p>

                </div>

            </div>

        </div>
    );
}


export default AdminHome;