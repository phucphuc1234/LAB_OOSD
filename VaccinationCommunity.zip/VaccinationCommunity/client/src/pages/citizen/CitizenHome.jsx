import {
    useEffect,
    useState
} from "react";

import {
    Link
} from "react-router-dom";

import citizenService
    from "../../services/citizenService";

import scheduleService
    from "../../services/scheduleService";

import historyService
    from "../../services/historyService";

import notificationService
    from "../../services/notificationService";

import doctorImage
    from "../../assets/images/doctor-vaccine.png";
function CitizenHome() {

    const [profile, setProfile] =
        useState(null);

    const [schedules, setSchedules] =
        useState([]);

    const [history, setHistory] =
        useState([]);

    const [notifications, setNotifications] =
        useState([]);

    const [loading, setLoading] =
        useState(true);


    useEffect(() => {

        const loadDashboard =
            async () => {

                try {

                    const [
                        profileRes,
                        scheduleRes,
                        historyRes,
                        notificationRes
                    ] = await Promise.all([

                        citizenService
                            .getMyProfile(),

                        scheduleService
                            .getMySchedules(),

                        historyService
                            .getMyHistory(),

                        notificationService
                            .getMyNotifications()

                    ]);


                    setProfile(
                        profileRes.data
                    );


                    setSchedules(
                        scheduleRes.data || []
                    );


                    setHistory(
                        historyRes.data || []
                    );


                    setNotifications(
                        notificationRes.data || []
                    );


                } catch (error) {

                    console.error(
                        "Lỗi dashboard:",
                        error
                    );

                } finally {

                    setLoading(false);
                }
            };


        loadDashboard();

    }, []);


    const unreadCount =
        notifications.filter(
            (item) =>
                !item.DaDoc
        ).length;


    const upcomingSchedules =
        schedules
            .filter((item) => {

                const date =
                    new Date(
                        item.NgayDuKien
                    );

                return (
                    date >= new Date() &&
                    item.TrangThai !==
                    "Đã hủy" &&
                    item.TrangThai !==
                    "Hoàn thành"
                );

            })
            .sort(
                (a, b) =>
                    new Date(
                        a.NgayDuKien
                    ) -
                    new Date(
                        b.NgayDuKien
                    )
            );


    const nearestSchedule =
        upcomingSchedules[0];


    const formatDate = (date) => {

        if (!date) {
            return "-";
        }

        return new Date(date)
            .toLocaleString(
                "vi-VN"
            );
    };


    if (loading) {

        return (

            <div
                className="
                    text-center
                    py-5
                "
            >
                Đang tải
                thông tin...
            </div>
        );
    }


    return (

        <div className="citizen-home">


            {/* =====================
                HERO
            ===================== */}

            <section
                className="
                    citizen-hero
                    mb-4
                "
            >

                <div>

                    <div
                        className="
                            hero-small-title
                        "
                    >
                        CỔNG TIÊM CHỦNG
                        CỘNG ĐỒNG
                    </div>


                    <h1>
                        Xin chào,{" "}

                        {
                            profile
                                ?.HoTen ||
                            "Người dân"
                        }
                    </h1>


                    <p>
                        Theo dõi lịch tiêm,
                        lịch sử tiêm chủng
                        và các thông báo
                        quan trọng của bạn.
                    </p>


                    <div
                        className="
                            d-flex
                            gap-2
                            flex-wrap
                        "
                    >

                        <Link
                            to="/citizen/schedules"
                            className="
                                btn
                                btn-light
                                fw-semibold
                            "
                        >
                            Đăng ký lịch tiêm
                        </Link>


                        <Link
                            to="/citizen/history"
                            className="
                                btn
                                btn-outline-light
                            "
                        >
                            Xem lịch sử tiêm
                        </Link>

                    </div>

                </div>


                <div className="hero-doctor-area">

                    <div className="hero-doctor-bg"></div>

                    <img
                        src={doctorImage}
                        alt="Bác sĩ tiêm chủng"
                        className="hero-doctor-image"
                    />

                </div>

            </section>


            {/* =====================
                THỐNG KÊ
            ===================== */}

            <div
                className="
                    row
                    g-3
                    mb-4
                "
            >


                <div
                    className="
                        col-md-6
                        col-xl-3
                    "
                >

                    <div
                        className="
                            home-stat-card
                        "
                    >

                        <div
                            className="
                                home-stat-icon
                                bg-primary-subtle
                            "
                        >
                            📅
                        </div>


                        <div>

                            <div
                                className="
                                    home-stat-label
                                "
                            >
                                Lịch tiêm
                            </div>

                            <div
                                className="
                                    home-stat-number
                                "
                            >
                                {
                                    schedules.length
                                }
                            </div>

                        </div>

                    </div>

                </div>


                <div
                    className="
                        col-md-6
                        col-xl-3
                    "
                >

                    <div
                        className="
                            home-stat-card
                        "
                    >

                        <div
                            className="
                                home-stat-icon
                                bg-success-subtle
                            "
                        >
                            💉
                        </div>


                        <div>

                            <div
                                className="
                                    home-stat-label
                                "
                            >
                                Mũi đã tiêm
                            </div>

                            <div
                                className="
                                    home-stat-number
                                "
                            >
                                {
                                    history.length
                                }
                            </div>

                        </div>

                    </div>

                </div>


                <div
                    className="
                        col-md-6
                        col-xl-3
                    "
                >

                    <div
                        className="
                            home-stat-card
                        "
                    >

                        <div
                            className="
                                home-stat-icon
                                bg-warning-subtle
                            "
                        >
                            🔔
                        </div>


                        <div>

                            <div
                                className="
                                    home-stat-label
                                "
                            >
                                Chưa đọc
                            </div>

                            <div
                                className="
                                    home-stat-number
                                "
                            >
                                {
                                    unreadCount
                                }
                            </div>

                        </div>

                    </div>

                </div>


                <div
                    className="
                        col-md-6
                        col-xl-3
                    "
                >

                    <div
                        className="
                            home-stat-card
                        "
                    >

                        <div
                            className="
                                home-stat-icon
                                bg-info-subtle
                            "
                        >
                            ⏰
                        </div>


                        <div>

                            <div
                                className="
                                    home-stat-label
                                "
                            >
                                Lịch sắp tới
                            </div>

                            <div
                                className="
                                    home-stat-number
                                "
                            >
                                {
                                    upcomingSchedules
                                        .length
                                }
                            </div>

                        </div>

                    </div>

                </div>

            </div>


            {/* =====================
                THÔNG TIN CHÍNH
            ===================== */}

            <div
                className="
                    row
                    g-4
                    mb-4
                "
            >


                {/* LỊCH GẦN NHẤT */}

                <div
                    className="
                        col-lg-7
                    "
                >

                    <div
                        className="
                            card
                            shadow-sm
                            h-100
                        "
                    >

                        <div
                            className="
                                card-header
                                d-flex
                                justify-content-between
                                align-items-center
                            "
                        >

                            <strong>
                                📅 Lịch tiêm
                                gần nhất
                            </strong>


                            <Link
                                to="/citizen/schedules"
                                className="
                                    text-decoration-none
                                "
                            >
                                Xem tất cả
                            </Link>

                        </div>


                        <div
                            className="
                                card-body
                            "
                        >

                            {
                                nearestSchedule
                                    ? (

                                        <div
                                            className="
                                            upcoming-card
                                        "
                                        >

                                            <div
                                                className="
                                                upcoming-date
                                            "
                                            >

                                                <span>
                                                    Thời gian
                                                </span>

                                                <strong>
                                                    {
                                                        formatDate(
                                                            nearestSchedule
                                                                .NgayDuKien
                                                        )
                                                    }
                                                </strong>

                                            </div>


                                            <div
                                                className="
                                                row
                                                mt-3
                                            "
                                            >

                                                <div
                                                    className="
                                                    col-md-4
                                                "
                                                >

                                                    <small
                                                        className="
                                                        text-muted
                                                    "
                                                    >
                                                        Vaccine
                                                    </small>

                                                    <div
                                                        className="
                                                        fw-semibold
                                                    "
                                                    >
                                                        {
                                                            nearestSchedule
                                                                .TenVaccine ||
                                                            "-"
                                                        }
                                                    </div>

                                                </div>


                                                <div
                                                    className="
                                                    col-md-4
                                                "
                                                >

                                                    <small
                                                        className="
                                                        text-muted
                                                    "
                                                    >
                                                        Mũi số
                                                    </small>

                                                    <div
                                                        className="
                                                        fw-semibold
                                                    "
                                                    >
                                                        Mũi{" "}
                                                        {
                                                            nearestSchedule
                                                                .MuiSo
                                                        }
                                                    </div>

                                                </div>


                                                <div
                                                    className="
                                                    col-md-4
                                                "
                                                >

                                                    <small
                                                        className="
                                                        text-muted
                                                    "
                                                    >
                                                        Trạng thái
                                                    </small>

                                                    <div>

                                                        <span
                                                            className="
                                                            badge
                                                            bg-primary
                                                        "
                                                        >
                                                            {
                                                                nearestSchedule
                                                                    .TrangThai
                                                            }
                                                        </span>

                                                    </div>

                                                </div>

                                            </div>


                                            <hr />


                                            <div>

                                                <small
                                                    className="
                                                    text-muted
                                                "
                                                >
                                                    Cơ sở tiêm
                                                </small>

                                                <div>
                                                    📍{" "}
                                                    {
                                                        nearestSchedule
                                                            .CoSoTiem ||
                                                        "Chưa cập nhật"
                                                    }
                                                </div>

                                            </div>

                                        </div>

                                    ) : (

                                        <div
                                            className="
                                            text-center
                                            py-4
                                        "
                                        >

                                            <div
                                                style={{
                                                    fontSize:
                                                        "40px"
                                                }}
                                            >
                                                📅
                                            </div>


                                            <p
                                                className="
                                                text-muted
                                            "
                                            >
                                                Bạn chưa có
                                                lịch tiêm
                                                sắp tới.
                                            </p>


                                            <Link
                                                to="/citizen/schedules"
                                                className="
                                                btn
                                                btn-primary
                                            "
                                            >
                                                Đăng ký lịch tiêm
                                            </Link>

                                        </div>

                                    )
                            }

                        </div>

                    </div>

                </div>


                {/* THÔNG BÁO */}

                <div
                    className="
                        col-lg-5
                    "
                >

                    <div
                        className="
                            card
                            shadow-sm
                            h-100
                        "
                    >

                        <div
                            className="
                                card-header
                                d-flex
                                justify-content-between
                            "
                        >

                            <strong>
                                🔔 Thông báo
                                mới
                            </strong>


                            <Link
                                to="/citizen/notifications"
                                className="
                                    text-decoration-none
                                "
                            >
                                Xem tất cả
                            </Link>

                        </div>


                        <div
                            className="
                                card-body
                            "
                        >

                            {
                                notifications
                                    .slice(0, 3)
                                    .map(
                                        (item) => (

                                            <div
                                                key={
                                                    item.MaThongBao
                                                }
                                                className="
                                                notification-home-item
                                            "
                                            >

                                                <div>

                                                    <strong>
                                                        {
                                                            item.TieuDe ||
                                                            "Thông báo"
                                                        }
                                                    </strong>


                                                    <p
                                                        className="
                                                        mb-0
                                                        text-muted
                                                    "
                                                    >
                                                        {
                                                            item.NoiDung
                                                        }
                                                    </p>

                                                </div>


                                                {
                                                    !item.DaDoc && (

                                                        <span
                                                            className="
                                                            notification-dot
                                                        "
                                                        />

                                                    )
                                                }

                                            </div>

                                        )
                                    )
                            }


                            {
                                notifications
                                    .length === 0 && (

                                    <div
                                        className="
                                            text-muted
                                            text-center
                                            py-4
                                        "
                                    >
                                        Chưa có
                                        thông báo.
                                    </div>

                                )
                            }

                        </div>

                    </div>

                </div>

            </div>


            {/* =====================
                TRUY CẬP NHANH
            ===================== */}

            <div className="mb-4">

                <h4 className="mb-3">
                    Truy cập nhanh
                </h4>


                <div
                    className="
                        row
                        g-3
                    "
                >

                    <QuickCard
                        icon="👤"
                        title="Hồ sơ cá nhân"
                        description="Xem và cập nhật thông tin cá nhân"
                        link="/citizen/profile"
                    />

                    <QuickCard
                        icon="📅"
                        title="Đăng ký lịch tiêm"
                        description="Đăng ký lịch tiêm vaccine"
                        link="/citizen/schedules"
                    />

                    <QuickCard
                        icon="💉"
                        title="Lịch sử tiêm"
                        description="Tra cứu các mũi đã tiêm"
                        link="/citizen/history"
                    />

                    <QuickCard
                        icon="⚠️"
                        title="Chống chỉ định"
                        description="Xem thông tin chống chỉ định"
                        link="/citizen/contraindications"
                    />

                </div>

            </div>


            {/* =====================
                HƯỚNG DẪN
            ===================== */}

            <div
                className="
                    card
                    shadow-sm
                    mb-4
                "
            >

                <div className="card-body">

                    <h4>
                        ℹ️ Lưu ý khi đi tiêm
                    </h4>


                    <div
                        className="
                            row
                            g-3
                            mt-1
                        "
                    >

                        <InfoItem
                            number="01"
                            title="Kiểm tra lịch"
                            text="Theo dõi ngày giờ và cơ sở tiêm trước khi đến."
                        />

                        <InfoItem
                            number="02"
                            title="Mang giấy tờ"
                            text="Chuẩn bị CCCD và các giấy tờ cần thiết."
                        />

                        <InfoItem
                            number="03"
                            title="Thông báo sức khỏe"
                            text="Trao đổi với nhân viên y tế về tình trạng sức khỏe."
                        />

                    </div>

                </div>

            </div>

        </div>
    );
}


function QuickCard({
    icon,
    title,
    description,
    link
}) {

    return (

        <div
            className="
                col-md-6
                col-xl-3
            "
        >

            <Link
                to={link}
                className="
                    quick-card
                    text-decoration-none
                "
            >

                <div
                    className="
                        quick-card-icon
                    "
                >
                    {icon}
                </div>


                <div>

                    <strong>
                        {title}
                    </strong>

                    <p>
                        {description}
                    </p>

                </div>

            </Link>

        </div>
    );
}


function InfoItem({
    number,
    title,
    text
}) {

    return (

        <div
            className="
                col-md-4
            "
        >

            <div
                className="
                    info-guide
                "
            >

                <div
                    className="
                        info-number
                    "
                >
                    {number}
                </div>


                <div>

                    <strong>
                        {title}
                    </strong>

                    <p>
                        {text}
                    </p>

                </div>

            </div>

        </div>
    );
}


export default CitizenHome;