import {
    useEffect,
    useState
} from "react";

import {
    Link
} from "react-router-dom";

import citizenService
    from "../../services/citizenService";

import vaccineService
    from "../../services/vaccineService";

import batchService
    from "../../services/batchService";

import scheduleService
    from "../../services/scheduleService";


function StaffHome() {

    const [citizens, setCitizens] =
        useState([]);

    const [vaccines, setVaccines] =
        useState([]);

    const [batches, setBatches] =
        useState([]);

    const [schedules, setSchedules] =
        useState([]);

    const [loading, setLoading] =
        useState(true);


    useEffect(() => {

        const loadDashboard =
            async () => {

                try {

                    const [
                        citizenRes,
                        vaccineRes,
                        batchRes,
                        scheduleRes
                    ] = await Promise.all([

                        citizenService
                            .getAllCitizens(),

                        vaccineService
                            .getAllVaccines(),

                        batchService
                            .getAllBatches(),

                        scheduleService
                            .getAllSchedules()

                    ]);


                    setCitizens(
                        citizenRes.data || []
                    );

                    setVaccines(
                        vaccineRes.data || []
                    );

                    setBatches(
                        batchRes.data || []
                    );

                    setSchedules(
                        scheduleRes.data || []
                    );

                } catch (error) {

                    console.error(
                        "Lỗi tải Staff Dashboard:",
                        error
                    );

                } finally {

                    setLoading(false);
                }
            };


        loadDashboard();

    }, []);


    const pendingSchedules =
        schedules.filter(
            (item) =>
                item.TrangThai ===
                "Đã lên lịch"
        );


    const confirmedSchedules =
        schedules.filter(
            (item) =>
                item.TrangThai ===
                "Đã xác nhận"
        );


    const activeBatches =
        batches.filter(
            (item) =>
                item.TrangThai ===
                "Đang sử dụng"
        );


    const formatDate = (date) => {

        if (!date) {
            return "-";
        }

        return new Date(date)
            .toLocaleString(
                "vi-VN"
            );
    };


    if (loading) {

        return (
            <div className="text-center py-5">
                Đang tải dữ liệu...
            </div>
        );
    }


    return (

        <div className="staff-home">


            {/* BANNER */}

            <section
                className="
                    staff-hero
                    mb-4
                "
            >

                <div className="staff-hero-content">

                    <div className="staff-hero-small">
                        KHU VỰC NHÂN VIÊN
                    </div>


                    <h1>
                        Quản lý tiêm chủng
                    </h1>


                    <p>
                        Theo dõi lịch tiêm,
                        người dân, vaccine
                        và xử lý các nghiệp vụ
                        tiêm chủng hằng ngày.
                    </p>


                    <div
                        className="
                            d-flex
                            gap-2
                            flex-wrap
                        "
                    >

                        <Link
                            to="/staff/schedules"
                            className="
                                btn
                                btn-light
                                fw-semibold
                            "
                        >
                            Xử lý lịch tiêm
                        </Link>


                        <Link
                            to="/staff/vaccinations"
                            className="
                                btn
                                btn-outline-light
                            "
                        >
                            Ghi nhận mũi tiêm
                        </Link>

                    </div>

                </div>


                <div className="staff-hero-icon">
                    🩺
                </div>

            </section>


            {/* THỐNG KÊ */}

            <div
                className="
                    row
                    g-3
                    mb-4
                "
            >

                <StatCard
                    icon="👥"
                    title="Người dân"
                    value={
                        citizens.length
                    }
                    className="bg-primary-subtle"
                />


                <StatCard
                    icon="💉"
                    title="Vaccine"
                    value={
                        vaccines.length
                    }
                    className="bg-success-subtle"
                />


                <StatCard
                    icon="📦"
                    title="Lô đang sử dụng"
                    value={
                        activeBatches.length
                    }
                    className="bg-warning-subtle"
                />


                <StatCard
                    icon="📅"
                    title="Lịch chờ xử lý"
                    value={
                        pendingSchedules.length
                    }
                    className="bg-danger-subtle"
                />

            </div>


            {/* LỊCH CẦN XỬ LÝ */}

            <div
                className="
                    row
                    g-4
                    mb-4
                "
            >

                <div className="col-lg-8">

                    <div
                        className="
                            card
                            shadow-sm
                            h-100
                        "
                    >

                        <div
                            className="
                                card-header
                                d-flex
                                justify-content-between
                                align-items-center
                            "
                        >

                            <strong>
                                📅 Lịch tiêm
                                cần xử lý
                            </strong>


                            <Link
                                to="/staff/schedules"
                                className="
                                    text-decoration-none
                                "
                            >
                                Xem tất cả
                            </Link>

                        </div>


                        <div className="card-body">

                            {
                                pendingSchedules
                                    .length === 0
                                    ? (

                                        <div
                                            className="
                                            text-center
                                            text-muted
                                            py-4
                                        "
                                        >
                                            Không có lịch
                                            chờ xử lý.
                                        </div>

                                    ) : (

                                        <div
                                            className="
                                            table-responsive
                                        "
                                        >

                                            <table
                                                className="
                                                table
                                                table-hover
                                                align-middle
                                            "
                                            >

                                                <thead>

                                                    <tr>
                                                        <th>
                                                            Người dân
                                                        </th>

                                                        <th>
                                                            Vaccine
                                                        </th>

                                                        <th>
                                                            Ngày tiêm
                                                        </th>

                                                        <th>
                                                            Trạng thái
                                                        </th>
                                                    </tr>

                                                </thead>


                                                <tbody>

                                                    {
                                                        pendingSchedules
                                                            .slice(
                                                                0,
                                                                5
                                                            )
                                                            .map(
                                                                (
                                                                    item
                                                                ) => (

                                                                    <tr
                                                                        key={
                                                                            item.MaLichTiem
                                                                        }
                                                                    >

                                                                        <td>
                                                                            {
                                                                                item.HoTen ||
                                                                                "-"
                                                                            }
                                                                        </td>


                                                                        <td>
                                                                            {
                                                                                item.TenVaccine ||
                                                                                "-"
                                                                            }
                                                                        </td>


                                                                        <td>
                                                                            {
                                                                                formatDate(
                                                                                    item.NgayDuKien
                                                                                )
                                                                            }
                                                                        </td>


                                                                        <td>

                                                                            <span
                                                                                className="
                                                                            badge
                                                                            bg-warning
                                                                            text-dark
                                                                        "
                                                                            >
                                                                                {
                                                                                    item.TrangThai
                                                                                }
                                                                            </span>

                                                                        </td>

                                                                    </tr>

                                                                )
                                                            )
                                                    }

                                                </tbody>

                                            </table>

                                        </div>

                                    )
                            }

                        </div>

                    </div>

                </div>


                {/* TỔNG QUAN */}

                <div className="col-lg-4">

                    <div
                        className="
                            card
                            shadow-sm
                            h-100
                        "
                    >

                        <div className="card-header">

                            <strong>
                                📊 Tổng quan
                                lịch tiêm
                            </strong>

                        </div>


                        <div className="card-body">

                            <DashboardInfo
                                title="Chờ xác nhận"
                                value={
                                    pendingSchedules
                                        .length
                                }
                                color="#ffc107"
                            />


                            <DashboardInfo
                                title="Đã xác nhận"
                                value={
                                    confirmedSchedules
                                        .length
                                }
                                color="#0d6efd"
                            />


                            <DashboardInfo
                                title="Tổng lịch tiêm"
                                value={
                                    schedules.length
                                }
                                color="#198754"
                            />


                            <hr />


                            <Link
                                to="/staff/schedules"
                                className="
                                    btn
                                    btn-success
                                    w-100
                                "
                            >
                                Quản lý lịch tiêm
                            </Link>

                        </div>

                    </div>

                </div>

            </div>


            {/* TRUY CẬP NHANH */}

            <section className="mb-4">

                <h4 className="mb-3">
                    Truy cập nhanh
                </h4>


                <div className="row g-3">

                    <QuickStaffCard
                        icon="👥"
                        title="Người dân"
                        description="Tra cứu và quản lý hồ sơ người dân"
                        link="/staff/citizens"
                    />


                    <QuickStaffCard
                        icon="💉"
                        title="Vaccine"
                        description="Quản lý danh mục vaccine"
                        link="/staff/vaccines"
                    />


                    <QuickStaffCard
                        icon="📦"
                        title="Lô vaccine"
                        description="Theo dõi số lượng và hạn sử dụng"
                        link="/staff/batches"
                    />


                    <QuickStaffCard
                        icon="📅"
                        title="Lịch tiêm"
                        description="Xác nhận và xử lý lịch tiêm"
                        link="/staff/schedules"
                    />


                    <QuickStaffCard
                        icon="✅"
                        title="Ghi nhận tiêm"
                        description="Ghi nhận kết quả mũi tiêm"
                        link="/staff/vaccinations"
                    />


                    <QuickStaffCard
                        icon="⚠️"
                        title="Chống chỉ định"
                        description="Quản lý thông tin chống chỉ định"
                        link="/staff/contraindications"
                    />


                    <QuickStaffCard
                        icon="📋"
                        title="Lịch sử tiêm"
                        description="Tra cứu lịch sử của người dân"
                        link="/staff/history"
                    />


                    <QuickStaffCard
                        icon="🔎"
                        title="Truy vết"
                        description="Truy vết theo lô vaccine"
                        link="/staff/trace"
                    />

                </div>

            </section>


            {/* QUY TRÌNH */}

            <div
                className="
                    card
                    shadow-sm
                    mb-4
                "
            >

                <div className="card-body">

                    <h4>
                        🩺 Quy trình xử lý tiêm chủng
                    </h4>


                    <div
                        className="
                            row
                            g-3
                            mt-1
                        "
                    >

                        <StaffGuide
                            number="01"
                            title="Kiểm tra lịch"
                            text="Tiếp nhận và xác nhận lịch đăng ký của người dân."
                        />


                        <StaffGuide
                            number="02"
                            title="Kiểm tra hồ sơ"
                            text="Kiểm tra thông tin sức khỏe và chống chỉ định."
                        />


                        <StaffGuide
                            number="03"
                            title="Ghi nhận mũi tiêm"
                            text="Chọn vaccine, lô vaccine và lưu kết quả tiêm."
                        />


                        <StaffGuide
                            number="04"
                            title="Theo dõi và truy vết"
                            text="Tra cứu lịch sử và truy vết lô khi cần thiết."
                        />

                    </div>

                </div>

            </div>

        </div>
    );
}


function StatCard({
    icon,
    title,
    value,
    className
}) {

    return (

        <div
            className="
                col-md-6
                col-xl-3
            "
        >

            <div className="staff-stat-card">

                <div
                    className={
                        `staff-stat-icon ${className}`
                    }
                >
                    {icon}
                </div>


                <div>

                    <div className="staff-stat-label">
                        {title}
                    </div>

                    <div className="staff-stat-number">
                        {value}
                    </div>

                </div>

            </div>

        </div>
    );
}


function DashboardInfo({
    title,
    value,
    color
}) {

    return (

        <div className="staff-dashboard-info">

            <div
                className="staff-info-dot"
                style={{
                    backgroundColor:
                        color
                }}
            />


            <span>
                {title}
            </span>


            <strong>
                {value}
            </strong>

        </div>

    );
}


function QuickStaffCard({
    icon,
    title,
    description,
    link
}) {

    return (

        <div
            className="
                col-md-6
                col-xl-3
            "
        >

            <Link
                to={link}
                className="
                    staff-quick-card
                    text-decoration-none
                "
            >

                <div className="staff-quick-icon">
                    {icon}
                </div>


                <div>

                    <strong>
                        {title}
                    </strong>

                    <p>
                        {description}
                    </p>

                </div>

            </Link>

        </div>
    );
}


function StaffGuide({
    number,
    title,
    text
}) {

    return (

        <div
            className="
                col-md-6
                col-xl-3
            "
        >

            <div className="staff-guide">

                <div className="staff-guide-number">
                    {number}
                </div>


                <div>

                    <strong>
                        {title}
                    </strong>

                    <p>
                        {text}
                    </p>

                </div>

            </div>

        </div>
    );
}


export default StaffHome;