import { Component, Suspense, lazy } from "react";

const ThreeUiHorizon = lazy(async () => {
    const mod = await import("@designcodeio/threeui");
    return { default: mod.AtTheHorizon };
});

class AmbientBoundary extends Component {
    constructor(props) {
        super(props);
        this.state = { failed: false };
    }

    static getDerivedStateFromError() {
        return { failed: true };
    }

    componentDidCatch(error) {
        console.warn("ThreeUI ambient fallback:", error);
    }

    render() {
        if (this.state.failed) {
            return null;
        }

        return this.props.children;
    }
}

function ThreeUiAmbient() {
    return (
        <AmbientBoundary>
            <Suspense fallback={null}>
                <div className="threeui-ambient" aria-hidden="true">
                    <ThreeUiHorizon />
                </div>
            </Suspense>
        </AmbientBoundary>
    );
}

export default ThreeUiAmbient;
