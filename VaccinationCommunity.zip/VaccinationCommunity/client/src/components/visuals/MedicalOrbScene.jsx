import { Canvas, useFrame } from "@react-three/fiber";
import { useMemo, useRef } from "react";

function OrbCluster() {
    const groupRef = useRef(null);
    const ringRef = useRef(null);

    const particles = useMemo(() => {
        return Array.from({ length: 26 }, (_, index) => {
            const angle = (index / 26) * Math.PI * 2;
            const radius = 2.1 + (index % 4) * 0.18;
            return {
                x: Math.cos(angle) * radius,
                y: Math.sin(angle * 1.7) * 0.75,
                z: Math.sin(angle) * radius * 0.58,
                scale: 0.035 + (index % 5) * 0.008,
            };
        });
    }, []);

    useFrame((state, delta) => {
        if (groupRef.current) {
            groupRef.current.rotation.y += delta * 0.12;
            groupRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.32) * 0.12;
        }

        if (ringRef.current) {
            ringRef.current.rotation.z -= delta * 0.18;
            ringRef.current.rotation.x = 1.1 + Math.sin(state.clock.elapsedTime * 0.24) * 0.08;
        }
    });

    return (
        <group ref={groupRef}>
            <mesh>
                <icosahedronGeometry args={[1.05, 3]} />
                <meshPhysicalMaterial
                    color="#53d4ff"
                    roughness={0.2}
                    metalness={0.16}
                    transmission={0.58}
                    thickness={1.3}
                    transparent
                    opacity={0.84}
                    emissive="#005d83"
                    emissiveIntensity={0.32}
                />
            </mesh>

            <mesh ref={ringRef}>
                <torusGeometry args={[1.62, 0.035, 16, 140]} />
                <meshStandardMaterial
                    color="#89f4d2"
                    emissive="#17b890"
                    emissiveIntensity={0.82}
                    transparent
                    opacity={0.88}
                />
            </mesh>

            <mesh rotation={[0.38, 0.8, 0.15]}>
                <torusGeometry args={[1.92, 0.018, 12, 140]} />
                <meshStandardMaterial
                    color="#9cc8ff"
                    emissive="#4b8de8"
                    emissiveIntensity={0.48}
                    transparent
                    opacity={0.62}
                />
            </mesh>

            {particles.map((particle, index) => (
                <mesh
                    key={index}
                    position={[particle.x, particle.y, particle.z]}
                    scale={particle.scale}
                >
                    <sphereGeometry args={[1, 16, 16]} />
                    <meshBasicMaterial
                        color={index % 3 === 0 ? "#8df3dc" : "#8fc8ff"}
                        transparent
                        opacity={0.78}
                    />
                </mesh>
            ))}
        </group>
    );
}

function MedicalOrbScene({ className = "" }) {
    return (
        <div className={`medical-orb-scene ${className}`} aria-hidden="true">
            <Canvas
                camera={{ position: [0, 0.2, 5.8], fov: 42 }}
                dpr={[1, 1.5]}
                gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}
            >
                <ambientLight intensity={1.7} />
                <pointLight position={[3, 2.4, 4]} intensity={18} color="#6cdcff" />
                <pointLight position={[-3, -2, 2]} intensity={11} color="#4ce5b5" />
                <pointLight position={[0, 4, -2]} intensity={8} color="#ffffff" />
                <OrbCluster />
            </Canvas>
        </div>
    );
}

export default MedicalOrbScene;
