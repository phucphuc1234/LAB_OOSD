import { useEffect, useMemo, useState } from "react";

import {
    NavLink,
    Outlet,
    useLocation,
    useNavigate,
} from "react-router-dom";

import {
    AnimatePresence,
    motion,
} from "motion/react";

import {
    Bell,
    ChevronRight,
    LogOut,
    Menu,
    Moon,
    ShieldCheck,
    Sparkles,
    Sun,
    X,
} from "lucide-react";

import authService from "../../services/authService";

import MedicalOrbScene from "../visuals/MedicalOrbScene";
import ThreeUiAmbient from "../visuals/ThreeUiAmbient";


// ======================================================
// THÔNG TIN THEO VAI TRÒ
// ======================================================

const roleMeta = {

    citizen: {
        label: "Người dân",

        eyebrow:
            "CỔNG SỨC KHỎE CÁ NHÂN",

        accent:
            "#2577ff",

        footer:
            "Theo dõi lịch tiêm, lịch sử và thông báo sức khỏe tại một nơi.",
    },


    staff: {
        label: "Nhân viên",

        eyebrow:
            "TRUNG TÂM ĐIỀU PHỐI TIÊM CHỦNG",

        accent:
            "#11a572",

        footer:
            "Quản lý công dân, vaccine, lịch tiêm và nghiệp vụ tiêm chủng.",
    },


    admin: {
        label: "Quản trị viên",

        eyebrow:
            "TRUNG TÂM QUẢN TRỊ HỆ THỐNG",

        accent:
            "#6b63ff",

        footer:
            "Giám sát tài khoản, phân quyền, vaccine và truy vết hệ thống.",
    },

};


// ======================================================
// ENTERPRISE SHELL
// ======================================================

function EnterpriseShell({
    role = "citizen",
    menuItems = [],
}) {

    const navigate =
        useNavigate();

    const location =
        useLocation();

    const user =
        authService.getCurrentUser();


    const meta =
        roleMeta[role] ||
        roleMeta.citizen;


    // ======================================================
    // SIDEBAR
    // ======================================================

    const [
        sidebarOpen,
        setSidebarOpen,
    ] = useState(false);


    // ======================================================
    // THEME
    // ======================================================

    const [
        theme,
        setTheme,
    ] = useState(() => {

        return (
            localStorage.getItem(
                "vaccination-theme"
            ) || "light"
        );

    });


    // ======================================================
    // ÁP DỤNG THEME
    // ======================================================

    useEffect(() => {

        document.documentElement.dataset.theme =
            theme;


        localStorage.setItem(
            "vaccination-theme",
            theme
        );

    }, [theme]);


    // ======================================================
    // MOBILE:
    // CHUYỂN ROUTE THÌ ĐÓNG SIDEBAR
    // ======================================================

    useEffect(() => {

        if (
            window.innerWidth < 1080
        ) {

            setSidebarOpen(false);

        }

    }, [location.pathname]);


    // ======================================================
    // USERNAME
    // ======================================================

    const username =

        user?.tenDangNhap ||

        user?.TenDangNhap ||

        user?.hoTen ||

        user?.HoTen ||

        "Tài khoản";


    // ======================================================
    // AVATAR INITIALS
    // ======================================================

    const initials =
        useMemo(() => {

            return (
                String(username)

                    .trim()

                    .split(/\s+/)

                    .slice(-2)

                    .map(
                        (part) =>
                            part
                                .charAt(0)
                                .toUpperCase()
                    )

                    .join("") || "U"
            );

        }, [username]);


    // ======================================================
    // LOGOUT
    // ======================================================

    const handleLogout = () => {

        authService.logout();


        navigate(
            "/login",
            {
                replace: true,
            }
        );

    };


    // ======================================================
    // RENDER
    // ======================================================

    return (

        <div

            className={
                `app-layout
                enterprise-shell
                ${role}-layout
                ${sidebarOpen
                    ? "shell-sidebar-open"
                    : "shell-sidebar-closed"
                }`
            }

            style={{
                "--role-accent":
                    meta.accent,
            }}

        >


            {/* =====================================================
                BACKGROUND EFFECT
            ===================================================== */}

            <div

                className="
                    shell-atmosphere
                    pointer-events-none
                    fixed
                    inset-0
                "

                aria-hidden="true"

            >

                <div
                    className="
                        shell-aurora
                        shell-aurora-a
                    "
                />


                <div
                    className="
                        shell-aurora
                        shell-aurora-b
                    "
                />


                <MedicalOrbScene />


                <ThreeUiAmbient />

            </div>


            {/* =====================================================
                NAVBAR
            ===================================================== */}

            <header

                className={
                    `app-navbar
                    enterprise-navbar
                    ${role}-navbar`
                }

            >


                {/* LEFT */}

                <div className="navbar-left">


                    {/* MENU BUTTON */}

                    <button

                        type="button"

                        className="
                            menu-toggle
                            enterprise-menu-toggle
                        "

                        onClick={() =>
                            setSidebarOpen(
                                (prev) =>
                                    !prev
                            )
                        }

                        aria-label={
                            sidebarOpen
                                ? "Đóng menu"
                                : "Mở menu"
                        }

                        aria-expanded={
                            sidebarOpen
                        }

                    >

                        {
                            sidebarOpen

                                ? (
                                    <X
                                        size={20}
                                    />
                                )

                                : (
                                    <Menu
                                        size={20}
                                    />
                                )
                        }

                    </button>


                    {/* BRAND */}

                    <NavLink

                        to={
                            menuItems[0]?.to ||
                            "/"
                        }

                        className="
                            enterprise-brand
                            text-decoration-none
                        "

                    >

                        <span
                            className="
                                enterprise-brand-mark
                            "
                        >

                            <ShieldCheck
                                size={20}
                            />

                        </span>


                        <span
                            className="
                                enterprise-brand-copy
                            "
                        >

                            <strong>
                                VaxCommunity
                            </strong>

                            <small>
                                Cổng theo dõi tiêm chủng cộng đồng
                            </small>

                        </span>

                    </NavLink>

                </div>


                {/* RIGHT */}

                <div
                    className="
                        enterprise-navbar-actions
                    "
                >


                    {/* SYSTEM STATUS */}

                    <div
                        className="
                            system-chip
                            d-none
                            d-md-flex
                        "
                    >

                        <span
                            className="
                                system-chip-dot
                            "
                        />

                        Hệ thống ổn định

                    </div>


                    {/* THEME */}

                    <button

                        type="button"

                        className="
                            navbar-icon-button
                        "

                        aria-label="
                            Đổi giao diện sáng tối
                        "

                        onClick={() =>

                            setTheme(
                                (prev) =>
                                    prev === "dark"
                                        ? "light"
                                        : "dark"
                            )

                        }

                    >

                        {
                            theme === "dark"

                                ? (
                                    <Sun
                                        size={18}
                                    />
                                )

                                : (
                                    <Moon
                                        size={18}
                                    />
                                )
                        }

                    </button>


                    {/* CITIZEN NOTIFICATION */}

                    {
                        role === "citizen" && (
                            <NavLink
                                to="/citizen/notifications"
                                className="navbar-icon-button text-decoration-none"
                                aria-label="Thông báo"
                            >
                                <Bell size={18} />
                                <span className="notification-ping" />
                            </NavLink>
                        )}


                    {/* USER */}

                    <div
                        className="
                            enterprise-user
                            d-none
                            d-sm-flex
                        "
                    >

                        <span
                            className="
                                enterprise-avatar
                            "
                        >
                            {initials}
                        </span>


                        <span
                            className="
                                enterprise-user-copy
                            "
                        >

                            <small>
                                {meta.label}
                            </small>

                            <strong>
                                {username}
                            </strong>

                        </span>

                    </div>


                    {/* LOGOUT */}

                    <button

                        type="button"

                        className="
                            logout-button
                        "

                        onClick={
                            handleLogout
                        }

                    >

                        <LogOut
                            size={16}
                        />

                        <span
                            className="
                                d-none
                                d-lg-inline
                            "
                        >
                            Đăng xuất
                        </span>

                    </button>

                </div>

            </header>


            {/* =====================================================
                SIDEBAR OVERLAY
            ===================================================== */}

            <div

                className={
                    `sidebar-overlay ${sidebarOpen
                        ? "show"
                        : ""
                    }`
                }

                onClick={() =>
                    setSidebarOpen(false)
                }

            />


            {/* =====================================================
                SIDEBAR
            ===================================================== */}

            <aside

                className={
                    `app-sidebar
                    enterprise-sidebar
                    ${sidebarOpen
                        ? "sidebar-open"
                        : ""
                    }`
                }

            >


                {/* SIDEBAR HEADER */}

                <div
                    className="
                        sidebar-header
                        enterprise-sidebar-header
                    "
                >

                    <div>

                        <div
                            className="
                                sidebar-title
                            "
                        >
                            {
                                meta.label
                                    .toUpperCase()
                            }
                        </div>


                        <div
                            className="
                                sidebar-subtitle
                            "
                        >
                            {meta.eyebrow}
                        </div>

                    </div>


                    <Sparkles
                        size={17}
                    />

                </div>


                {/* MENU */}

                <nav
                    className="
                        sidebar-menu
                        enterprise-sidebar-menu
                    "
                >

                    {
                        menuItems.map(
                            (
                                item,
                                index
                            ) => {

                                const Icon =
                                    item.icon;


                                return (

                                    <motion.div

                                        key={
                                            item.to
                                        }

                                        initial={{
                                            opacity: 0,
                                            x: -8,
                                        }}

                                        animate={{
                                            opacity: 1,
                                            x: 0,
                                        }}

                                        transition={{
                                            delay:
                                                0.025 *
                                                index,

                                            duration:
                                                0.2,
                                        }}

                                    >

                                        <NavLink

                                            to={
                                                item.to
                                            }

                                            end={
                                                item.end
                                            }

                                            className={({
                                                isActive,
                                            }) =>

                                                isActive
                                                    ? "sidebar-link active"
                                                    : "sidebar-link"

                                            }

                                        >

                                            <span
                                                className="
                                                    sidebar-link-icon
                                                "
                                            >

                                                <Icon
                                                    size={18}
                                                    strokeWidth={1.9}
                                                />

                                            </span>


                                            <span>
                                                {
                                                    item.label
                                                }
                                            </span>


                                            <ChevronRight

                                                className="
                                                    sidebar-link-arrow
                                                "

                                                size={15}

                                            />

                                        </NavLink>

                                    </motion.div>

                                );

                            }
                        )
                    }

                </nav>


                {/* SECURITY CARD */}

                <div
                    className="
                        sidebar-health-card
                    "
                >

                    <span
                        className="
                            sidebar-health-icon
                        "
                    >

                        <ShieldCheck
                            size={18}
                        />

                    </span>


                    <div>

                        <strong>
                            Dữ liệu được bảo vệ
                        </strong>


                        <p>
                            Kết nối an toàn với hệ thống tiêm chủng.
                        </p>

                    </div>

                </div>

            </aside>


            {/* =====================================================
                BODY
            ===================================================== */}

            <div
                className="
                    app-body
                    enterprise-body
                "
            >


                <main
                    className="
                        app-content
                        enterprise-content
                    "
                >


                    {/* =================================================
                        PAGE TRANSITION

                        KHÔNG ĐẶT TITLE Ở ĐÂY NỮA
                        → tránh lặp tiêu đề giữa Shell và từng Page
                    ================================================= */}

                    <AnimatePresence
                        mode="wait"
                        initial={false}
                    >

                        <motion.div

                            key={
                                location.pathname
                            }

                            className="
                                enterprise-route-stage
                            "

                            initial={{
                                opacity: 0,
                                y: 12,
                                filter:
                                    "blur(4px)",
                            }}

                            animate={{
                                opacity: 1,
                                y: 0,
                                filter:
                                    "blur(0px)",
                            }}

                            exit={{
                                opacity: 0,
                                y: -6,
                                filter:
                                    "blur(2px)",
                            }}

                            transition={{
                                duration:
                                    0.26,

                                ease: [
                                    0.22,
                                    1,
                                    0.36,
                                    1,
                                ],
                            }}

                        >

                            <Outlet />

                        </motion.div>

                    </AnimatePresence>


                    {/* =================================================
                        FOOTER
                    ================================================= */}

                    <footer
                        className="
                            citizen-footer
                            enterprise-footer
                        "
                    >

                        <div>

                            <strong>
                                VaxCommunity · Nền tảng tiêm chủng số
                            </strong>


                            <p>
                                {meta.footer}
                            </p>

                        </div>


                        <div
                            className="
                                footer-right
                            "
                        >

                            <span
                                className="
                                    footer-status-dot
                                "
                            />

                            Vận hành an toàn · 2026

                        </div>

                    </footer>

                </main>

            </div>

        </div>

    );

}


export default EnterpriseShell;