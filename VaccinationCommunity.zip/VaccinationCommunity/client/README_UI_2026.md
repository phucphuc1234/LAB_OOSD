# VaxCommunity UI 2026

Bản frontend này được nâng cấp trực tiếp từ source `client` hiện tại, giữ nguyên route, service và nghiệp vụ API.

## Công nghệ giao diện

- React 19 + Vite 8
- Bootstrap 5.3 (giữ để tương thích các form/bảng cũ)
- Tailwind CSS 4 + `@tailwindcss/vite`
- Motion for React: page transition, stagger, hover/tap animation
- Three.js + React Three Fiber: nền 3D nhẹ, không cần asset ngoài
- ThreeUI Community (`@designcodeio/threeui`): ambient WebGL được lazy-load và có fallback
- Lucide React: icon đồng nhất cho menu và action

## Những phần đã nâng cấp

- Login enterprise 2026 với 3D/WebGL, glass UI và responsive.
- Layout dùng chung cho Người dân / Nhân viên / Quản trị viên.
- Sidebar desktop/mobile hiện đại, icon Lucide, animation Motion.
- Header có theme sáng/tối, trạng thái hệ thống, thông báo và avatar.
- Chuyển trang có transition mượt.
- Dashboard cũ được giữ nguyên nghiệp vụ nhưng được restyle bằng design system mới.
- Tất cả card, table, form, button, badge, progress được đồng bộ giao diện.
- Dark mode lưu trong `localStorage`.
- Tôn trọng `prefers-reduced-motion`.
- ThreeUI/Three.js chỉ đóng vai trò trang trí; nếu WebGL lỗi thì nghiệp vụ vẫn dùng bình thường.

## File mới chính

```text
src/
├── components/
│   ├── common/
│   │   └── EnterpriseShell.jsx
│   └── visuals/
│       ├── MedicalOrbScene.jsx
│       └── ThreeUiAmbient.jsx
└── assets/
    └── enterprise.css
```

## File đã cập nhật

```text
package.json
vite.config.js
src/main.jsx
src/index.css
src/layouts/CitizenLayout.jsx
src/layouts/StaffLayout.jsx
src/layouts/AdminLayout.jsx
src/pages/auth/LoginPage.jsx
src/pages/auth/RegisterPage.jsx
```

## Cài dependency

Do file ZIP không kèm `node_modules`, trong thư mục `client` chạy:

```bash
npm install
```

Sau đó chạy:

```bash
npm run dev
```

Nếu muốn kiểm tra production build:

```bash
npm run build
```

## Lưu ý

- Backend và các file trong `src/services/` không bị đổi.
- Các URL `/citizen/*`, `/staff/*`, `/admin/*` được giữ nguyên.
- Không cần thay database/API để dùng giao diện mới.
- `@designcodeio/threeui` được lazy-load để hạn chế ảnh hưởng thời gian tải ban đầu.
