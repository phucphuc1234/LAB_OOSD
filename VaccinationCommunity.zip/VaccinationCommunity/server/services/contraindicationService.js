const contraindicationRepository =
    require(
        "../repositories/contraindicationRepository"
    );

const citizenRepository =
    require(
        "../repositories/citizenRepository"
    );


const createError = (
    message,
    statusCode = 400
) => {
    const error = new Error(message);
    error.statusCode = statusCode;

    return error;
};


const getAll = async () => {
    return await contraindicationRepository
        .findAll();
};


const getById = async (id) => {

    const data =
        await contraindicationRepository
            .findById(id);

    if (!data) {
        throw createError(
            "Không tìm thấy chống chỉ định.",
            404
        );
    }

    return data;
};


// Người dân xem của mình
const getMyContraindications = async (
    maTaiKhoan
) => {

    const citizen =
        await citizenRepository
            .findByAccountId(maTaiKhoan);

    if (!citizen) {
        throw createError(
            "Không tìm thấy hồ sơ người dân.",
            404
        );
    }

    return await contraindicationRepository
        .findByCitizenId(
            citizen.MaNguoiDan
        );
};


const createContraindication = async (
    data,
    maNguoiXacNhan
) => {

    if (
        !data.maNguoiDan ||
        !data.noiDung
    ) {
        throw createError(
            "Vui lòng nhập người dân và nội dung chống chỉ định.",
            400
        );
    }


    const citizen =
        await citizenRepository.findById(
            data.maNguoiDan
        );

    if (!citizen) {
        throw createError(
            "Người dân không tồn tại.",
            404
        );
    }


    return await contraindicationRepository
        .create(
            data,
            maNguoiXacNhan
        );
};


const updateContraindication = async (
    id,
    data,
    maTaiKhoan
) => {

    const current =
        await contraindicationRepository
            .findById(id);

    if (!current) {
        throw createError(
            "Không tìm thấy chống chỉ định.",
            404
        );
    }


    if (
        data.trangThai !== undefined &&
        ![
            "Đã xác nhận",
            "Đã hủy"
        ].includes(data.trangThai)
    ) {
        throw createError(
            "Trạng thái chống chỉ định không hợp lệ.",
            400
        );
    }


    return await contraindicationRepository
        .update(
            id,
            data,
            maTaiKhoan
        );
};


module.exports = {
    getAll,
    getById,
    getMyContraindications,
    createContraindication,
    updateContraindication
};