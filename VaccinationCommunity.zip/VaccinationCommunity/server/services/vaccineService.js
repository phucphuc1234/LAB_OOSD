const vaccineRepository =
    require("../repositories/vaccineRepository");


const createError = (
    message,
    statusCode = 400
) => {
    const error = new Error(message);

    error.statusCode = statusCode;

    return error;
};


// Danh sách vaccine
const getAllVaccines = async () => {
    return await vaccineRepository.findAll();
};


// Chi tiết vaccine
const getVaccineById = async (
    maVaccine
) => {
    const vaccine =
        await vaccineRepository.findById(
            maVaccine
        );

    if (!vaccine) {
        throw createError(
            "Không tìm thấy vaccine.",
            404
        );
    }

    return vaccine;
};


// Thêm vaccine
const createVaccine = async (data) => {
    if (!data.tenVaccine) {
        throw createError(
            "Tên vaccine không được để trống.",
            400
        );
    }


    if (
        data.soMuiKhuyenNghi !== undefined &&
        data.soMuiKhuyenNghi <= 0
    ) {
        throw createError(
            "Số mũi khuyến nghị phải lớn hơn 0.",
            400
        );
    }


    if (
        data.khoangCachMui !== undefined &&
        data.khoangCachMui < 0
    ) {
        throw createError(
            "Khoảng cách mũi không được âm.",
            400
        );
    }


    const existing =
        await vaccineRepository.findByName(
            data.tenVaccine
        );

    if (existing) {
        throw createError(
            "Tên vaccine đã tồn tại.",
            409
        );
    }


    return await vaccineRepository.create(
        data
    );
};


// Cập nhật vaccine
const updateVaccine = async (
    maVaccine,
    data
) => {
    const current =
        await vaccineRepository.findById(
            maVaccine
        );

    if (!current) {
        throw createError(
            "Không tìm thấy vaccine.",
            404
        );
    }


    if (
        data.soMuiKhuyenNghi !== undefined &&
        data.soMuiKhuyenNghi <= 0
    ) {
        throw createError(
            "Số mũi khuyến nghị phải lớn hơn 0.",
            400
        );
    }


    if (
        data.khoangCachMui !== undefined &&
        data.khoangCachMui < 0
    ) {
        throw createError(
            "Khoảng cách mũi không được âm.",
            400
        );
    }


    if (data.tenVaccine) {
        const existing =
            await vaccineRepository.findByName(
                data.tenVaccine
            );

        if (
            existing &&
            existing.MaVaccine !==
            Number(maVaccine)
        ) {
            throw createError(
                "Tên vaccine đã tồn tại.",
                409
            );
        }
    }


    return await vaccineRepository.update(
        maVaccine,
        data
    );
};


// Bật / ngừng sử dụng
const changeStatus = async (
    maVaccine,
    trangThai
) => {
    const vaccine =
        await vaccineRepository.findById(
            maVaccine
        );

    if (!vaccine) {
        throw createError(
            "Không tìm thấy vaccine.",
            404
        );
    }


    if (
        trangThai !== true &&
        trangThai !== false
    ) {
        throw createError(
            "Trạng thái phải là true hoặc false.",
            400
        );
    }


    return await vaccineRepository
        .updateStatus(
            maVaccine,
            trangThai
        );
};


module.exports = {
    getAllVaccines,
    getVaccineById,
    createVaccine,
    updateVaccine,
    changeStatus
};