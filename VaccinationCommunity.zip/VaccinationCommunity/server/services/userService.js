const userRepository =
    require("../repositories/userRepository");


const createError = (
    message,
    statusCode = 400
) => {
    const error = new Error(message);

    error.statusCode = statusCode;

    return error;
};


const getAllUsers = async () => {
    return await userRepository.findAll();
};


const getUserById = async (
    maTaiKhoan
) => {

    const user =
        await userRepository.findById(
            maTaiKhoan
        );

    if (!user) {
        throw createError(
            "Không tìm thấy tài khoản.",
            404
        );
    }

    return user;
};


const changeStatus = async (
    maTaiKhoan,
    trangThai,
    adminId
) => {

    const user =
        await userRepository.findById(
            maTaiKhoan
        );

    if (!user) {
        throw createError(
            "Không tìm thấy tài khoản.",
            404
        );
    }


    if (
        trangThai !== true &&
        trangThai !== false
    ) {
        throw createError(
            "Trạng thái phải là true hoặc false.",
            400
        );
    }


    if (
        Number(maTaiKhoan) ===
        Number(adminId)
    ) {
        throw createError(
            "Bạn không thể tự khóa tài khoản đang đăng nhập.",
            400
        );
    }


    return await userRepository
        .updateStatus(
            maTaiKhoan,
            trangThai,
            adminId
        );
};


const changeRole = async (
    maTaiKhoan,
    maVaiTro,
    adminId
) => {

    const user =
        await userRepository.findById(
            maTaiKhoan
        );

    if (!user) {
        throw createError(
            "Không tìm thấy tài khoản.",
            404
        );
    }


    const role =
        await userRepository.findRoleById(
            maVaiTro
        );

    if (!role) {
        throw createError(
            "Vai trò không tồn tại.",
            404
        );
    }


    if (
        Number(maTaiKhoan) ===
        Number(adminId)
    ) {
        throw createError(
            "Không thể tự thay đổi vai trò của tài khoản đang đăng nhập.",
            400
        );
    }


    return await userRepository
        .updateRole(
            maTaiKhoan,
            maVaiTro,
            adminId
        );
};


module.exports = {
    getAllUsers,
    getUserById,
    changeStatus,
    changeRole
};