const scheduleRepository =
    require("../repositories/scheduleRepository");

const citizenRepository =
    require("../repositories/citizenRepository");

const vaccineRepository =
    require("../repositories/vaccineRepository");


const createError = (
    message,
    statusCode = 400
) => {
    const error = new Error(message);
    error.statusCode = statusCode;

    return error;
};


// Danh sách lịch
const getAllSchedules = async () => {
    return await scheduleRepository.findAll();
};


// Chi tiết lịch
const getScheduleById = async (
    maLichTiem
) => {
    const schedule =
        await scheduleRepository.findById(
            maLichTiem
        );

    if (!schedule) {
        throw createError(
            "Không tìm thấy lịch tiêm.",
            404
        );
    }

    return schedule;
};


// Người dân xem lịch của mình
const getMySchedules = async (
    maTaiKhoan
) => {
    const citizen =
        await citizenRepository
            .findByAccountId(maTaiKhoan);

    if (!citizen) {
        throw createError(
            "Không tìm thấy hồ sơ người dân.",
            404
        );
    }

    return await scheduleRepository
        .findByCitizenId(
            citizen.MaNguoiDan
        );
};


// Tạo lịch
const createSchedule = async (
    data,
    maNhanVienTao
) => {
    if (
        !data.maNguoiDan ||
        !data.maVaccine ||
        !data.muiSo ||
        !data.ngayDuKien
    ) {
        throw createError(
            "Vui lòng nhập đầy đủ thông tin lịch tiêm.",
            400
        );
    }


    if (data.muiSo <= 0) {
        throw createError(
            "Mũi tiêm phải lớn hơn 0.",
            400
        );
    }


    const citizen =
        await citizenRepository.findById(
            data.maNguoiDan
        );

    if (!citizen) {
        throw createError(
            "Người dân không tồn tại.",
            404
        );
    }


    const vaccine =
        await vaccineRepository.findById(
            data.maVaccine
        );

    if (!vaccine) {
        throw createError(
            "Vaccine không tồn tại.",
            404
        );
    }


    if (!vaccine.TrangThai) {
        throw createError(
            "Vaccine hiện đang ngừng sử dụng.",
            400
        );
    }


    if (
        isNaN(
            new Date(
                data.ngayDuKien
            ).getTime()
        )
    ) {
        throw createError(
            "Ngày dự kiến không hợp lệ.",
            400
        );
    }


    return await scheduleRepository.create(
        data,
        maNhanVienTao
    );
};


// Cập nhật lịch
const updateSchedule = async (
    maLichTiem,
    data
) => {
    const current =
        await scheduleRepository.findById(
            maLichTiem
        );

    if (!current) {
        throw createError(
            "Không tìm thấy lịch tiêm.",
            404
        );
    }


    if (
        data.muiSo !== undefined &&
        data.muiSo <= 0
    ) {
        throw createError(
            "Mũi tiêm phải lớn hơn 0.",
            400
        );
    }


    if (data.maVaccine) {
        const vaccine =
            await vaccineRepository.findById(
                data.maVaccine
            );

        if (!vaccine) {
            throw createError(
                "Vaccine không tồn tại.",
                404
            );
        }


        if (!vaccine.TrangThai) {
            throw createError(
                "Vaccine đang ngừng sử dụng.",
                400
            );
        }
    }


    if (
        data.ngayDuKien &&
        isNaN(
            new Date(
                data.ngayDuKien
            ).getTime()
        )
    ) {
        throw createError(
            "Ngày dự kiến không hợp lệ.",
            400
        );
    }


    return await scheduleRepository.update(
        maLichTiem,
        data
    );
};


// Đổi trạng thái
const changeStatus = async (
    maLichTiem,
    trangThai
) => {
    const schedule =
        await scheduleRepository.findById(
            maLichTiem
        );

    if (!schedule) {
        throw createError(
            "Không tìm thấy lịch tiêm.",
            404
        );
    }


    const allowedStatus = [
        "Đã lên lịch",
        "Đã xác nhận",
        "Đã tiêm",
        "Hoàn thành",
        "Đã hủy",
        "Vắng mặt"
    ];


    if (
        !allowedStatus.includes(
            trangThai
        )
    ) {
        throw createError(
            "Trạng thái lịch tiêm không hợp lệ.",
            400
        );
    }


    return await scheduleRepository
        .updateStatus(
            maLichTiem,
            trangThai
        );
};
const createMySchedule = async (
    maTaiKhoan,
    data
) => {

    const citizen =
        await citizenRepository
            .findByAccountId(
                maTaiKhoan
            );

    if (!citizen) {
        const error =
            new Error(
                "Không tìm thấy hồ sơ người dân."
            );

        error.statusCode = 404;

        throw error;
    }


    if (
        !data.maVaccine ||
        !data.muiSo ||
        !data.ngayDuKien
    ) {
        const error =
            new Error(
                "Vui lòng nhập đầy đủ vaccine, mũi tiêm và ngày tiêm."
            );

        error.statusCode = 400;

        throw error;
    }


    const ngayDuKien =
        new Date(data.ngayDuKien);

    if (
        Number.isNaN(
            ngayDuKien.getTime()
        )
    ) {
        const error =
            new Error(
                "Ngày tiêm không hợp lệ."
            );

        error.statusCode = 400;

        throw error;
    }


    if (
        ngayDuKien <= new Date()
    ) {
        const error =
            new Error(
                "Ngày tiêm phải lớn hơn thời điểm hiện tại."
            );

        error.statusCode = 400;

        throw error;
    }


    const schedules =
        await scheduleRepository
            .findByCitizenId(
                citizen.MaNguoiDan
            );


    const duplicate =
        schedules.find((item) => {

            const sameVaccine =
                Number(item.MaVaccine) ===
                Number(data.maVaccine);

            const activeStatus =
                item.TrangThai ===
                "Đã lên lịch" ||
                item.TrangThai ===
                "Đã xác nhận";

            return (
                sameVaccine &&
                activeStatus
            );
        });


    if (duplicate) {

        const error =
            new Error(
                "Bạn đã có lịch tiêm cho vaccine này đang chờ xử lý."
            );

        error.statusCode = 409;

        throw error;
    }


    const result =
        await scheduleRepository
            .createByCitizen(
                citizen.MaNguoiDan,
                data
            );


    return {
        maLichTiem:
            result.MaLichTiem,

        message:
            "Đăng ký lịch tiêm thành công."
    };
};

module.exports = {
    getAllSchedules,
    getScheduleById,
    getMySchedules,
    createSchedule,
    updateSchedule,
    changeStatus,
    createMySchedule
};