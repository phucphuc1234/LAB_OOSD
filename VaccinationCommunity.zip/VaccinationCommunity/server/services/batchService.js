const batchRepository =
    require("../repositories/batchRepository");

const vaccineRepository =
    require("../repositories/vaccineRepository");


const createError = (
    message,
    statusCode = 400
) => {
    const error = new Error(message);

    error.statusCode = statusCode;

    return error;
};


const getAllBatches = async () => {
    return await batchRepository.findAll();
};


const getBatchById = async (maLo) => {
    const batch =
        await batchRepository.findById(maLo);

    if (!batch) {
        throw createError(
            "Không tìm thấy lô vaccine.",
            404
        );
    }

    return batch;
};


const createBatch = async (data) => {

    if (
        !data.maLoVaccine ||
        !data.maVaccine ||
        !data.hanSuDung ||
        data.soLuongNhap === undefined
    ) {
        throw createError(
            "Vui lòng nhập đầy đủ thông tin bắt buộc.",
            400
        );
    }


    const vaccine =
        await vaccineRepository.findById(
            data.maVaccine
        );

    if (!vaccine) {
        throw createError(
            "Vaccine không tồn tại.",
            404
        );
    }


    const existing =
        await batchRepository.findByCode(
            data.maLoVaccine
        );

    if (existing) {
        throw createError(
            "Mã lô vaccine đã tồn tại.",
            409
        );
    }


    if (data.soLuongNhap <= 0) {
        throw createError(
            "Số lượng nhập phải lớn hơn 0.",
            400
        );
    }


    if (
        data.ngaySanXuat &&
        new Date(data.hanSuDung) <=
        new Date(data.ngaySanXuat)
    ) {
        throw createError(
            "Hạn sử dụng phải sau ngày sản xuất.",
            400
        );
    }


    const soLuongCon =
        data.soLuongCon ??
        data.soLuongNhap;


    if (
        soLuongCon < 0 ||
        soLuongCon > data.soLuongNhap
    ) {
        throw createError(
            "Số lượng còn không hợp lệ.",
            400
        );
    }


    return await batchRepository.create({
        ...data,
        soLuongCon
    });
};


const updateBatch = async (
    maLo,
    data
) => {

    const current =
        await batchRepository.findById(
            maLo
        );

    if (!current) {
        throw createError(
            "Không tìm thấy lô vaccine.",
            404
        );
    }


    const soLuongNhap =
        data.soLuongNhap ??
        current.SoLuongNhap;

    const soLuongCon =
        data.soLuongCon ??
        current.SoLuongCon;


    if (soLuongNhap <= 0) {
        throw createError(
            "Số lượng nhập phải lớn hơn 0.",
            400
        );
    }


    if (
        soLuongCon < 0 ||
        soLuongCon > soLuongNhap
    ) {
        throw createError(
            "Số lượng còn phải nằm trong khoảng 0 đến số lượng nhập.",
            400
        );
    }


    const ngaySanXuat =
        data.ngaySanXuat ??
        current.NgaySanXuat;

    const hanSuDung =
        data.hanSuDung ??
        current.HanSuDung;


    if (
        ngaySanXuat &&
        new Date(hanSuDung) <=
        new Date(ngaySanXuat)
    ) {
        throw createError(
            "Hạn sử dụng phải sau ngày sản xuất.",
            400
        );
    }


    return await batchRepository.update(
        maLo,
        data
    );
};


const changeStatus = async (
    maLo,
    trangThai
) => {

    const batch =
        await batchRepository.findById(
            maLo
        );

    if (!batch) {
        throw createError(
            "Không tìm thấy lô vaccine.",
            404
        );
    }


    const allowedStatus = [
        "Đang sử dụng",
        "Tạm ngừng",
        "Hết hàng",
        "Hết hạn"
    ];


    if (
        !allowedStatus.includes(
            trangThai
        )
    ) {
        throw createError(
            "Trạng thái lô vaccine không hợp lệ.",
            400
        );
    }


    return await batchRepository
        .updateStatus(
            maLo,
            trangThai
        );
};


module.exports = {
    getAllBatches,
    getBatchById,
    createBatch,
    updateBatch,
    changeStatus
};