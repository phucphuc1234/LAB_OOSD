const vaccinationRepository =
    require("../repositories/vaccinationRepository");

const citizenRepository =
    require("../repositories/citizenRepository");

const vaccineRepository =
    require("../repositories/vaccineRepository");

const batchRepository =
    require("../repositories/batchRepository");

const scheduleRepository =
    require("../repositories/scheduleRepository");


const createError = (
    message,
    statusCode = 400
) => {

    const error = new Error(message);

    error.statusCode = statusCode;

    return error;
};


// Chi tiết mũi tiêm
const getVaccinationById = async (
    maMuiTiem
) => {

    const vaccination =
        await vaccinationRepository
            .findById(maMuiTiem);

    if (!vaccination) {
        throw createError(
            "Không tìm thấy mũi tiêm.",
            404
        );
    }

    return vaccination;
};


// Ghi nhận mũi tiêm
const createVaccination = async (
    data,
    maNhanVien
) => {

    if (
        !data.maNguoiDan ||
        !data.maVaccine ||
        !data.maLo ||
        !data.muiSo
    ) {
        throw createError(
            "Vui lòng nhập đầy đủ thông tin bắt buộc.",
            400
        );
    }


    if (data.muiSo <= 0) {
        throw createError(
            "Mũi tiêm phải lớn hơn 0.",
            400
        );
    }


    // Kiểm tra người dân
    const citizen =
        await citizenRepository.findById(
            data.maNguoiDan
        );

    if (!citizen) {
        throw createError(
            "Người dân không tồn tại.",
            404
        );
    }


    // Kiểm tra vaccine
    const vaccine =
        await vaccineRepository.findById(
            data.maVaccine
        );

    if (!vaccine) {
        throw createError(
            "Vaccine không tồn tại.",
            404
        );
    }


    if (!vaccine.TrangThai) {
        throw createError(
            "Vaccine đang ngừng sử dụng.",
            400
        );
    }


    // Kiểm tra lô
    const batch =
        await batchRepository.findById(
            data.maLo
        );

    if (!batch) {
        throw createError(
            "Lô vaccine không tồn tại.",
            404
        );
    }


    if (
        batch.MaVaccine !==
        Number(data.maVaccine)
    ) {
        throw createError(
            "Lô vaccine không thuộc vaccine đã chọn.",
            400
        );
    }


    if (batch.SoLuongCon <= 0) {
        throw createError(
            "Lô vaccine đã hết hàng.",
            400
        );
    }


    if (
        batch.TrangThai !==
        "Đang sử dụng"
    ) {
        throw createError(
            "Lô vaccine hiện không được sử dụng.",
            400
        );
    }


    if (
        new Date(batch.HanSuDung) <
        new Date()
    ) {
        throw createError(
            "Lô vaccine đã hết hạn.",
            400
        );
    }


    // Nếu có lịch tiêm thì kiểm tra lịch
    if (data.maLichTiem) {

        const schedule =
            await scheduleRepository
                .findById(
                    data.maLichTiem
                );

        if (!schedule) {
            throw createError(
                "Lịch tiêm không tồn tại.",
                404
            );
        }


        if (
            schedule.MaNguoiDan !==
            Number(data.maNguoiDan)
        ) {
            throw createError(
                "Lịch tiêm không thuộc người dân này.",
                400
            );
        }


        if (
            schedule.MaVaccine !==
            Number(data.maVaccine)
        ) {
            throw createError(
                "Vaccine không khớp với lịch tiêm.",
                400
            );
        }


        if (
            schedule.TrangThai ===
            "Đã hủy"
        ) {
            throw createError(
                "Không thể ghi nhận tiêm cho lịch đã hủy.",
                400
            );
        }
    }


    return await vaccinationRepository
        .create(
            data,
            maNhanVien
        );
};


module.exports = {
    getVaccinationById,
    createVaccination
};