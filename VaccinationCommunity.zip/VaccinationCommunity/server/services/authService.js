const bcrypt = require("bcrypt");

const authRepository =
    require("../repositories/authRepository");

const { generateToken } =
    require("../utils/jwt");


const createError = (message, statusCode = 400) => {

    const error = new Error(message);

    error.statusCode = statusCode;

    return error;
};


const register = async (data) => {

    const {
        tenDangNhap,
        matKhau,
        email,
        soDienThoai,
        hoTen,
        ngaySinh,
        gioiTinh,
        cccd
    } = data;


    if (
        !tenDangNhap ||
        !matKhau ||
        !email ||
        !soDienThoai ||
        !hoTen ||
        !ngaySinh ||
        !gioiTinh ||
        !cccd
    ) {
        throw createError(
            "Vui lòng nhập đầy đủ thông tin.",
            400
        );
    }


    if (matKhau.length < 6) {
        throw createError(
            "Mật khẩu phải có ít nhất 6 ký tự.",
            400
        );
    }


    const existingUsername =
        await authRepository.findByUsername(
            tenDangNhap
        );

    if (existingUsername) {
        throw createError(
            "Tên đăng nhập đã tồn tại.",
            409
        );
    }


    const existingEmail =
        await authRepository.findByEmail(email);

    if (existingEmail) {
        throw createError(
            "Email đã được sử dụng.",
            409
        );
    }


    const existingCCCD =
        await authRepository.findByCCCD(cccd);

    if (existingCCCD) {
        throw createError(
            "CCCD đã tồn tại.",
            409
        );
    }


    const hashedPassword =
        await bcrypt.hash(matKhau, 10);


    const result =
        await authRepository.createCitizenAccount({
            ...data,
            matKhau: hashedPassword
        });


    return {
        message: "Đăng ký tài khoản thành công.",
        ...result
    };
};


const login = async (tenDangNhap, matKhau) => {

    if (!tenDangNhap || !matKhau) {
        throw createError(
            "Vui lòng nhập tên đăng nhập và mật khẩu.",
            400
        );
    }


    const user =
        await authRepository.findByUsername(
            tenDangNhap
        );


    if (!user) {
        throw createError(
            "Tên đăng nhập hoặc mật khẩu không đúng.",
            401
        );
    }


    if (!user.TrangThai) {
        throw createError(
            "Tài khoản đã bị khóa.",
            403
        );
    }


    const passwordMatch =
        await bcrypt.compare(
            matKhau,
            user.MatKhau
        );


    if (!passwordMatch) {
        throw createError(
            "Tên đăng nhập hoặc mật khẩu không đúng.",
            401
        );
    }


    await authRepository.updateLastLogin(
        user.MaTaiKhoan
    );


    const token = generateToken(user);


    return {
        token,

        user: {
            maTaiKhoan: user.MaTaiKhoan,
            tenDangNhap: user.TenDangNhap,
            email: user.Email,
            maVaiTro: user.MaVaiTro,
            tenVaiTro: user.TenVaiTro
        }
    };
};
const changePassword = async (
    maTaiKhoan,
    matKhauHienTai,
    matKhauMoi
) => {
    if (
        !matKhauHienTai ||
        !matKhauMoi
    ) {
        throw new Error(
            "Vui lòng nhập đầy đủ mật khẩu."
        );
    }

    if (matKhauMoi.length < 6) {
        throw new Error(
            "Mật khẩu mới phải có ít nhất 6 ký tự."
        );
    }

    if (matKhauHienTai === matKhauMoi) {
        throw new Error(
            "Mật khẩu mới phải khác mật khẩu hiện tại."
        );
    }


    const account =
        await authRepository
            .findAccountById(
                maTaiKhoan
            );

    if (!account) {
        const error =
            new Error(
                "Không tìm thấy tài khoản."
            );

        error.statusCode = 404;

        throw error;
    }


    const isMatch =
        await bcrypt.compare(
            matKhauHienTai,
            account.MatKhau
        );

    if (!isMatch) {
        const error =
            new Error(
                "Mật khẩu hiện tại không đúng."
            );

        error.statusCode = 400;

        throw error;
    }


    const hashedPassword =
        await bcrypt.hash(
            matKhauMoi,
            10
        );


    await authRepository
        .updatePassword(
            maTaiKhoan,
            hashedPassword
        );


    return {
        message:
            "Đổi mật khẩu thành công."
    };
};

module.exports = {
    register,
    login,
    changePassword
};