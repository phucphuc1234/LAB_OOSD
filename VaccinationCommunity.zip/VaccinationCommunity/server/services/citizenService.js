const citizenRepository =
    require("../repositories/citizenRepository");


const createError = (
    message,
    statusCode = 400
) => {

    const error = new Error(message);

    error.statusCode = statusCode;

    return error;
};


// Xem hồ sơ của chính người đăng nhập
const getMyProfile = async (maTaiKhoan) => {

    const citizen =
        await citizenRepository
            .findByAccountId(maTaiKhoan);

    if (!citizen) {
        throw createError(
            "Không tìm thấy hồ sơ người dân.",
            404
        );
    }

    return citizen;
};


// Người dân tự cập nhật hồ sơ
const updateMyProfile = async (
    maTaiKhoan,
    data
) => {

    const citizen =
        await citizenRepository
            .findByAccountId(maTaiKhoan);

    if (!citizen) {
        throw createError(
            "Không tìm thấy hồ sơ người dân.",
            404
        );
    }


    const result =
        await citizenRepository
            .updateOwnProfile(
                maTaiKhoan,
                data
            );

    return result;
};


// Nhân viên / Admin xem danh sách
const getAllCitizens = async () => {

    return await citizenRepository.findAll();
};


// Xem chi tiết một người dân
const getCitizenById = async (
    maNguoiDan
) => {

    const citizen =
        await citizenRepository
            .findById(maNguoiDan);

    if (!citizen) {
        throw createError(
            "Không tìm thấy người dân.",
            404
        );
    }

    return citizen;
};


module.exports = {
    getMyProfile,
    updateMyProfile,
    getAllCitizens,
    getCitizenById
};