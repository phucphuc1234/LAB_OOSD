const { sql } = require("../config/database");


// Lấy toàn bộ lô vaccine
const findAll = async () => {
    const pool = await sql.connect();

    const result = await pool
        .request()
        .query(`
            SELECT
                lv.MaLo,
                lv.MaLoVaccine,
                lv.MaVaccine,
                v.TenVaccine,
                lv.NgaySanXuat,
                lv.HanSuDung,
                lv.SoLuongNhap,
                lv.SoLuongCon,
                lv.NgayNhap,
                lv.TrangThai,
                lv.GhiChu
            FROM LOVACCINE lv
            INNER JOIN VACCINE v
                ON lv.MaVaccine = v.MaVaccine
            ORDER BY lv.MaLo DESC
        `);

    return result.recordset;
};


// Tìm lô theo ID
const findById = async (maLo) => {
    const pool = await sql.connect();

    const result = await pool
        .request()
        .input("MaLo", sql.Int, maLo)
        .query(`
            SELECT
                lv.MaLo,
                lv.MaLoVaccine,
                lv.MaVaccine,
                v.TenVaccine,
                lv.NgaySanXuat,
                lv.HanSuDung,
                lv.SoLuongNhap,
                lv.SoLuongCon,
                lv.NgayNhap,
                lv.TrangThai,
                lv.GhiChu
            FROM LOVACCINE lv
            INNER JOIN VACCINE v
                ON lv.MaVaccine = v.MaVaccine
            WHERE lv.MaLo = @MaLo
        `);

    return result.recordset[0] || null;
};


// Tìm theo mã lô
const findByCode = async (maLoVaccine) => {
    const pool = await sql.connect();

    const result = await pool
        .request()
        .input(
            "MaLoVaccine",
            sql.VarChar(50),
            maLoVaccine
        )
        .query(`
            SELECT
                MaLo,
                MaLoVaccine,
                MaVaccine
            FROM LOVACCINE
            WHERE MaLoVaccine = @MaLoVaccine
        `);

    return result.recordset[0] || null;
};


// Thêm lô vaccine
const create = async (data) => {
    const pool = await sql.connect();

    const result = await pool
        .request()

        .input(
            "MaLoVaccine",
            sql.VarChar(50),
            data.maLoVaccine
        )

        .input(
            "MaVaccine",
            sql.Int,
            data.maVaccine
        )

        .input(
            "NgaySanXuat",
            sql.Date,
            data.ngaySanXuat
                ? new Date(data.ngaySanXuat)
                : null
        )

        .input(
            "HanSuDung",
            sql.Date,
            new Date(data.hanSuDung)
        )

        .input(
            "SoLuongNhap",
            sql.Int,
            data.soLuongNhap
        )

        .input(
            "SoLuongCon",
            sql.Int,
            data.soLuongCon
        )

        .input(
            "TrangThai",
            sql.NVarChar(50),
            data.trangThai || "Đang sử dụng"
        )

        .input(
            "GhiChu",
            sql.NVarChar(255),
            data.ghiChu || null
        )

        .query(`
            INSERT INTO LOVACCINE
            (
                MaLoVaccine,
                MaVaccine,
                NgaySanXuat,
                HanSuDung,
                SoLuongNhap,
                SoLuongCon,
                TrangThai,
                GhiChu
            )
            OUTPUT INSERTED.*
            VALUES
            (
                @MaLoVaccine,
                @MaVaccine,
                @NgaySanXuat,
                @HanSuDung,
                @SoLuongNhap,
                @SoLuongCon,
                @TrangThai,
                @GhiChu
            )
        `);

    return result.recordset[0];
};


// Cập nhật lô
const update = async (maLo, data) => {
    const pool = await sql.connect();

    const result = await pool
        .request()

        .input("MaLo", sql.Int, maLo)

        .input(
            "NgaySanXuat",
            sql.Date,
            data.ngaySanXuat
                ? new Date(data.ngaySanXuat)
                : null
        )

        .input(
            "HanSuDung",
            sql.Date,
            data.hanSuDung
                ? new Date(data.hanSuDung)
                : null
        )

        .input(
            "SoLuongNhap",
            sql.Int,
            data.soLuongNhap ?? null
        )

        .input(
            "SoLuongCon",
            sql.Int,
            data.soLuongCon ?? null
        )

        .input(
            "GhiChu",
            sql.NVarChar(255),
            data.ghiChu ?? null
        )

        .query(`
            UPDATE LOVACCINE
            SET
                NgaySanXuat =
                    COALESCE(@NgaySanXuat, NgaySanXuat),

                HanSuDung =
                    COALESCE(@HanSuDung, HanSuDung),

                SoLuongNhap =
                    COALESCE(@SoLuongNhap, SoLuongNhap),

                SoLuongCon =
                    COALESCE(@SoLuongCon, SoLuongCon),

                GhiChu =
                    COALESCE(@GhiChu, GhiChu)

            WHERE MaLo = @MaLo;

            SELECT *
            FROM LOVACCINE
            WHERE MaLo = @MaLo;
        `);

    return result.recordset[0] || null;
};


// Đổi trạng thái lô
const updateStatus = async (
    maLo,
    trangThai
) => {
    const pool = await sql.connect();

    const result = await pool
        .request()

        .input(
            "MaLo",
            sql.Int,
            maLo
        )

        .input(
            "TrangThai",
            sql.NVarChar(50),
            trangThai
        )

        .query(`
            UPDATE LOVACCINE
            SET TrangThai = @TrangThai
            WHERE MaLo = @MaLo;

            SELECT *
            FROM LOVACCINE
            WHERE MaLo = @MaLo;
        `);

    return result.recordset[0] || null;
};


module.exports = {
    findAll,
    findById,
    findByCode,
    create,
    update,
    updateStatus
};