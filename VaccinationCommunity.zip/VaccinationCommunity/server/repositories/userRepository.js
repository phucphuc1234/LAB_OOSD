const { sql } = require("../config/database");


// Danh sách tài khoản
const findAll = async () => {
    const pool = await sql.connect();

    const result = await pool
        .request()
        .query(`
            SELECT
                tk.MaTaiKhoan,
                tk.TenDangNhap,
                tk.Email,
                tk.SoDienThoai,
                tk.MaVaiTro,
                vt.TenVaiTro,
                tk.TrangThai,
                tk.NgayTao,
                tk.LanDangNhapCuoi
            FROM TAIKHOAN tk
            INNER JOIN VAITRO vt
                ON tk.MaVaiTro = vt.MaVaiTro
            ORDER BY tk.MaTaiKhoan DESC
        `);

    return result.recordset;
};


// Chi tiết tài khoản
const findById = async (maTaiKhoan) => {
    const pool = await sql.connect();

    const result = await pool
        .request()
        .input(
            "MaTaiKhoan",
            sql.Int,
            maTaiKhoan
        )
        .query(`
            SELECT
                tk.MaTaiKhoan,
                tk.TenDangNhap,
                tk.Email,
                tk.SoDienThoai,
                tk.MaVaiTro,
                vt.TenVaiTro,
                tk.TrangThai,
                tk.NgayTao,
                tk.LanDangNhapCuoi
            FROM TAIKHOAN tk
            INNER JOIN VAITRO vt
                ON tk.MaVaiTro = vt.MaVaiTro
            WHERE tk.MaTaiKhoan = @MaTaiKhoan
        `);

    return result.recordset[0] || null;
};


// Kiểm tra vai trò
const findRoleById = async (maVaiTro) => {
    const pool = await sql.connect();

    const result = await pool
        .request()
        .input(
            "MaVaiTro",
            sql.Int,
            maVaiTro
        )
        .query(`
            SELECT *
            FROM VAITRO
            WHERE MaVaiTro = @MaVaiTro
              AND TrangThai = 1
        `);

    return result.recordset[0] || null;
};


// Đổi trạng thái tài khoản
const updateStatus = async (
    maTaiKhoan,
    trangThai,
    adminId
) => {
    const pool = await sql.connect();

    const transaction =
        new sql.Transaction(pool);

    try {

        await transaction.begin();

        const oldRequest =
            new sql.Request(transaction);

        oldRequest.input(
            "MaTaiKhoan",
            sql.Int,
            maTaiKhoan
        );

        const oldResult =
            await oldRequest.query(`
                SELECT *
                FROM TAIKHOAN
                WHERE MaTaiKhoan = @MaTaiKhoan
            `);

        const oldData =
            oldResult.recordset[0];


        const request =
            new sql.Request(transaction);

        request.input(
            "MaTaiKhoan",
            sql.Int,
            maTaiKhoan
        );

        request.input(
            "TrangThai",
            sql.Bit,
            trangThai
        );

        const result =
            await request.query(`
                UPDATE TAIKHOAN
                SET TrangThai = @TrangThai
                WHERE MaTaiKhoan = @MaTaiKhoan;

                SELECT
                    tk.MaTaiKhoan,
                    tk.TenDangNhap,
                    tk.Email,
                    tk.SoDienThoai,
                    tk.MaVaiTro,
                    vt.TenVaiTro,
                    tk.TrangThai
                FROM TAIKHOAN tk
                INNER JOIN VAITRO vt
                    ON tk.MaVaiTro = vt.MaVaiTro
                WHERE tk.MaTaiKhoan = @MaTaiKhoan;
            `);

        const newData =
            result.recordset[0];


        const history =
            new sql.Request(transaction);

        history.input(
            "TenBang",
            sql.VarChar(100),
            "TAIKHOAN"
        );

        history.input(
            "MaBanGhi",
            sql.Int,
            maTaiKhoan
        );

        history.input(
            "HanhDong",
            sql.NVarChar(50),
            "Cập nhật trạng thái"
        );

        history.input(
            "DuLieuCu",
            sql.NVarChar(sql.MAX),
            JSON.stringify(oldData)
        );

        history.input(
            "DuLieuMoi",
            sql.NVarChar(sql.MAX),
            JSON.stringify(newData)
        );

        history.input(
            "MaTaiKhoan",
            sql.Int,
            adminId
        );

        await history.query(`
            INSERT INTO LICHSUHIEUCHINH
            (
                TenBang,
                MaBanGhi,
                HanhDong,
                DuLieuCu,
                DuLieuMoi,
                MaTaiKhoan
            )
            VALUES
            (
                @TenBang,
                @MaBanGhi,
                @HanhDong,
                @DuLieuCu,
                @DuLieuMoi,
                @MaTaiKhoan
            )
        `);


        await transaction.commit();

        return newData;

    } catch (error) {

        try {
            await transaction.rollback();
        } catch (_) { }

        throw error;
    }
};


// Đổi vai trò
const updateRole = async (
    maTaiKhoan,
    maVaiTro,
    adminId
) => {
    const pool = await sql.connect();

    const transaction =
        new sql.Transaction(pool);

    try {

        await transaction.begin();


        const oldRequest =
            new sql.Request(transaction);

        oldRequest.input(
            "MaTaiKhoan",
            sql.Int,
            maTaiKhoan
        );

        const oldResult =
            await oldRequest.query(`
                SELECT *
                FROM TAIKHOAN
                WHERE MaTaiKhoan = @MaTaiKhoan
            `);

        const oldData =
            oldResult.recordset[0];


        const request =
            new sql.Request(transaction);

        request.input(
            "MaTaiKhoan",
            sql.Int,
            maTaiKhoan
        );

        request.input(
            "MaVaiTro",
            sql.Int,
            maVaiTro
        );

        const result =
            await request.query(`
                UPDATE TAIKHOAN
                SET MaVaiTro = @MaVaiTro
                WHERE MaTaiKhoan = @MaTaiKhoan;

                SELECT
                    tk.MaTaiKhoan,
                    tk.TenDangNhap,
                    tk.Email,
                    tk.MaVaiTro,
                    vt.TenVaiTro,
                    tk.TrangThai
                FROM TAIKHOAN tk
                INNER JOIN VAITRO vt
                    ON tk.MaVaiTro = vt.MaVaiTro
                WHERE tk.MaTaiKhoan = @MaTaiKhoan;
            `);

        const newData =
            result.recordset[0];


        const history =
            new sql.Request(transaction);

        history.input(
            "TenBang",
            sql.VarChar(100),
            "TAIKHOAN"
        );

        history.input(
            "MaBanGhi",
            sql.Int,
            maTaiKhoan
        );

        history.input(
            "HanhDong",
            sql.NVarChar(50),
            "Phân quyền"
        );

        history.input(
            "DuLieuCu",
            sql.NVarChar(sql.MAX),
            JSON.stringify(oldData)
        );

        history.input(
            "DuLieuMoi",
            sql.NVarChar(sql.MAX),
            JSON.stringify(newData)
        );

        history.input(
            "MaTaiKhoan",
            sql.Int,
            adminId
        );

        await history.query(`
            INSERT INTO LICHSUHIEUCHINH
            (
                TenBang,
                MaBanGhi,
                HanhDong,
                DuLieuCu,
                DuLieuMoi,
                MaTaiKhoan
            )
            VALUES
            (
                @TenBang,
                @MaBanGhi,
                @HanhDong,
                @DuLieuCu,
                @DuLieuMoi,
                @MaTaiKhoan
            )
        `);


        await transaction.commit();

        return newData;

    } catch (error) {

        try {
            await transaction.rollback();
        } catch (_) { }

        throw error;
    }
};


module.exports = {
    findAll,
    findById,
    findRoleById,
    updateStatus,
    updateRole
};