const { sql } = require("../config/database");


// Tìm mũi tiêm theo ID
const findById = async (maMuiTiem) => {
    const pool = await sql.connect();

    const result = await pool
        .request()
        .input(
            "MaMuiTiem",
            sql.Int,
            maMuiTiem
        )
        .query(`
            SELECT
                mt.MaMuiTiem,
                mt.MaNguoiDan,
                nd.HoTen,
                mt.MaVaccine,
                v.TenVaccine,
                mt.MaLo,
                lv.MaLoVaccine,
                mt.MaLichTiem,
                mt.MuiSo,
                mt.NgayTiem,
                mt.CoSoTiem,
                mt.MaNhanVien,
                tk.TenDangNhap AS NhanVienGhiNhan,
                mt.KetQua,
                mt.PhanUngSauTiem,
                mt.GhiChu,
                mt.NgayTao
            FROM MUITIEM mt
            INNER JOIN NGUOIDAN nd
                ON mt.MaNguoiDan = nd.MaNguoiDan
            INNER JOIN VACCINE v
                ON mt.MaVaccine = v.MaVaccine
            INNER JOIN LOVACCINE lv
                ON mt.MaLo = lv.MaLo
            INNER JOIN TAIKHOAN tk
                ON mt.MaNhanVien = tk.MaTaiKhoan
            WHERE mt.MaMuiTiem = @MaMuiTiem
        `);

    return result.recordset[0] || null;
};


// Tạo mũi tiêm bằng transaction
const create = async (
    data,
    maNhanVien
) => {

    const pool = await sql.connect();

    const transaction =
        new sql.Transaction(pool);

    try {

        await transaction.begin();


        // 1. Kiểm tra lô vaccine và khóa dòng
        const batchRequest =
            new sql.Request(transaction);

        batchRequest.input(
            "MaLo",
            sql.Int,
            data.maLo
        );

        const batchResult =
            await batchRequest.query(`
                SELECT
                    MaLo,
                    MaVaccine,
                    MaLoVaccine,
                    HanSuDung,
                    SoLuongCon,
                    TrangThai
                FROM LOVACCINE
                WITH (UPDLOCK, ROWLOCK)
                WHERE MaLo = @MaLo
            `);


        if (
            batchResult.recordset.length === 0
        ) {
            throw new Error(
                "Không tìm thấy lô vaccine."
            );
        }


        const batch =
            batchResult.recordset[0];


        if (
            batch.MaVaccine !==
            Number(data.maVaccine)
        ) {
            throw new Error(
                "Lô vaccine không thuộc vaccine đã chọn."
            );
        }


        if (batch.SoLuongCon <= 0) {
            throw new Error(
                "Lô vaccine đã hết số lượng."
            );
        }


        if (
            batch.TrangThai !==
            "Đang sử dụng"
        ) {
            throw new Error(
                "Lô vaccine hiện không được phép sử dụng."
            );
        }


        // 2. Ghi nhận mũi tiêm
        const vaccinationRequest =
            new sql.Request(transaction);


        vaccinationRequest.input(
            "MaNguoiDan",
            sql.Int,
            data.maNguoiDan
        );

        vaccinationRequest.input(
            "MaVaccine",
            sql.Int,
            data.maVaccine
        );

        vaccinationRequest.input(
            "MaLo",
            sql.Int,
            data.maLo
        );

        vaccinationRequest.input(
            "MaLichTiem",
            sql.Int,
            data.maLichTiem || null
        );

        vaccinationRequest.input(
            "MuiSo",
            sql.Int,
            data.muiSo
        );

        vaccinationRequest.input(
            "NgayTiem",
            sql.DateTime2,
            data.ngayTiem
                ? new Date(data.ngayTiem)
                : new Date()
        );

        vaccinationRequest.input(
            "CoSoTiem",
            sql.NVarChar(255),
            data.coSoTiem || null
        );

        vaccinationRequest.input(
            "MaNhanVien",
            sql.Int,
            maNhanVien
        );

        vaccinationRequest.input(
            "KetQua",
            sql.NVarChar(100),
            data.ketQua ||
            "Đã tiêm thành công"
        );

        vaccinationRequest.input(
            "PhanUngSauTiem",
            sql.NVarChar(500),
            data.phanUngSauTiem || null
        );

        vaccinationRequest.input(
            "GhiChu",
            sql.NVarChar(500),
            data.ghiChu || null
        );


        const vaccinationResult =
            await vaccinationRequest.query(`
                INSERT INTO MUITIEM
                (
                    MaNguoiDan,
                    MaVaccine,
                    MaLo,
                    MaLichTiem,
                    MuiSo,
                    NgayTiem,
                    CoSoTiem,
                    MaNhanVien,
                    KetQua,
                    PhanUngSauTiem,
                    GhiChu
                )
                OUTPUT INSERTED.*
                VALUES
                (
                    @MaNguoiDan,
                    @MaVaccine,
                    @MaLo,
                    @MaLichTiem,
                    @MuiSo,
                    @NgayTiem,
                    @CoSoTiem,
                    @MaNhanVien,
                    @KetQua,
                    @PhanUngSauTiem,
                    @GhiChu
                )
            `);


        const vaccination =
            vaccinationResult.recordset[0];


        // 3. Trừ số lượng lô
        const quantityRequest =
            new sql.Request(transaction);

        quantityRequest.input(
            "MaLo",
            sql.Int,
            data.maLo
        );

        await quantityRequest.query(`
            UPDATE LOVACCINE
            SET
                SoLuongCon = SoLuongCon - 1,

                TrangThai =
                    CASE
                        WHEN SoLuongCon - 1 = 0
                        THEN N'Hết hàng'
                        ELSE TrangThai
                    END

            WHERE MaLo = @MaLo;
        `);


        // 4. Cập nhật lịch tiêm
        if (data.maLichTiem) {

            const scheduleRequest =
                new sql.Request(transaction);

            scheduleRequest.input(
                "MaLichTiem",
                sql.Int,
                data.maLichTiem
            );

            await scheduleRequest.query(`
                UPDATE LICHTIEM
                SET TrangThai = N'Đã tiêm'
                WHERE MaLichTiem =
                    @MaLichTiem;
            `);
        }


        // 5. Lưu lịch sử
        const historyRequest =
            new sql.Request(transaction);

        historyRequest.input(
            "TenBang",
            sql.VarChar(100),
            "MUITIEM"
        );

        historyRequest.input(
            "MaBanGhi",
            sql.Int,
            vaccination.MaMuiTiem
        );

        historyRequest.input(
            "HanhDong",
            sql.NVarChar(50),
            "Thêm mới"
        );

        historyRequest.input(
            "DuLieuMoi",
            sql.NVarChar(sql.MAX),
            JSON.stringify(vaccination)
        );

        historyRequest.input(
            "MaTaiKhoan",
            sql.Int,
            maNhanVien
        );

        await historyRequest.query(`
            INSERT INTO LICHSUHIEUCHINH
            (
                TenBang,
                MaBanGhi,
                HanhDong,
                DuLieuMoi,
                MaTaiKhoan
            )
            VALUES
            (
                @TenBang,
                @MaBanGhi,
                @HanhDong,
                @DuLieuMoi,
                @MaTaiKhoan
            )
        `);


        await transaction.commit();

        return vaccination;

    } catch (error) {

        try {
            await transaction.rollback();
        } catch (_) { }

        throw error;
    }
};


module.exports = {
    findById,
    create
};