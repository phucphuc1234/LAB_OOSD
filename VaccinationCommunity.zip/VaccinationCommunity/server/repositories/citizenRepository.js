const { sql } = require("../config/database");


// Tìm hồ sơ người dân theo tài khoản đăng nhập
const findByAccountId = async (maTaiKhoan) => {

    const pool = await sql.connect();

    const result = await pool
        .request()
        .input(
            "MaTaiKhoan",
            sql.Int,
            maTaiKhoan
        )
        .query(`
            SELECT
                nd.MaNguoiDan,
                nd.MaTaiKhoan,
                nd.HoTen,
                nd.NgaySinh,
                nd.GioiTinh,
                nd.CCCD,
                nd.SoBHYT,
                nd.SoDienThoai,
                nd.Email,
                nd.DiaChi,
                nd.PhuongXa,
                nd.QuanHuyen,
                nd.TinhThanh,
                nd.NgayTao,
                nd.NgayCapNhat,
                nd.TrangThai
            FROM NGUOIDAN nd
            WHERE nd.MaTaiKhoan = @MaTaiKhoan
        `);

    return result.recordset[0] || null;
};


// Người dân cập nhật hồ sơ cá nhân
const updateOwnProfile = async (
    maTaiKhoan,
    data
) => {
    const pool = await sql.connect();

    const result = await pool
        .request()

        .input(
            "MaTaiKhoan",
            sql.Int,
            maTaiKhoan
        )

        .input(
            "SoDienThoai",
            sql.VarChar(20),
            data.soDienThoai ?? null
        )

        .input(
            "Email",
            sql.VarChar(150),
            data.email ?? null
        )

        .input(
            "DiaChi",
            sql.NVarChar(255),
            data.diaChi ?? null
        )

        .input(
            "PhuongXa",
            sql.NVarChar(100),
            data.phuongXa ?? null
        )

        .input(
            "QuanHuyen",
            sql.NVarChar(100),
            data.quanHuyen ?? null
        )

        .input(
            "TinhThanh",
            sql.NVarChar(100),
            data.tinhThanh ?? null
        )

        .query(`
            UPDATE NGUOIDAN
            SET
                SoDienThoai =
                    COALESCE(@SoDienThoai, SoDienThoai),

                Email =
                    COALESCE(@Email, Email),

                DiaChi =
                    COALESCE(@DiaChi, DiaChi),

                PhuongXa =
                    COALESCE(@PhuongXa, PhuongXa),

                QuanHuyen =
                    COALESCE(@QuanHuyen, QuanHuyen),

                TinhThanh =
                    COALESCE(@TinhThanh, TinhThanh),

                NgayCapNhat = GETDATE()

            WHERE MaTaiKhoan = @MaTaiKhoan;

            SELECT *
            FROM NGUOIDAN
            WHERE MaTaiKhoan = @MaTaiKhoan;
        `);

    return result.recordset[0] || null;
};

// Danh sách tất cả người dân
const findAll = async () => {

    const pool = await sql.connect();

    const result = await pool
        .request()
        .query(`
            SELECT
                MaNguoiDan,
                HoTen,
                NgaySinh,
                GioiTinh,
                CCCD,
                SoBHYT,
                SoDienThoai,
                Email,
                DiaChi,
                PhuongXa,
                QuanHuyen,
                TinhThanh,
                TrangThai
            FROM NGUOIDAN
            ORDER BY MaNguoiDan DESC
        `);

    return result.recordset;
};


// Tìm người dân theo ID
const findById = async (maNguoiDan) => {

    const pool = await sql.connect();

    const result = await pool
        .request()
        .input(
            "MaNguoiDan",
            sql.Int,
            maNguoiDan
        )
        .query(`
            SELECT
                MaNguoiDan,
                MaTaiKhoan,
                HoTen,
                NgaySinh,
                GioiTinh,
                CCCD,
                SoBHYT,
                SoDienThoai,
                Email,
                DiaChi,
                PhuongXa,
                QuanHuyen,
                TinhThanh,
                NgayTao,
                NgayCapNhat,
                TrangThai
            FROM NGUOIDAN
            WHERE MaNguoiDan = @MaNguoiDan
        `);

    return result.recordset[0] || null;
};


module.exports = {
    findByAccountId,
    updateOwnProfile,
    findAll,
    findById
};