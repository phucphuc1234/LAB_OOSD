const { sql } = require("../config/database");


// Danh sách tất cả lịch tiêm
const findAll = async () => {
    const pool = await sql.connect();

    const result = await pool
        .request()
        .query(`
            SELECT
                lt.MaLichTiem,
                lt.MaNguoiDan,
                nd.HoTen,
                lt.MaVaccine,
                v.TenVaccine,
                lt.MuiSo,
                lt.NgayDuKien,
                lt.CoSoTiem,
                lt.TrangThai,
                lt.GhiChu,
                lt.NgayTao,
                lt.MaNhanVienTao
            FROM LICHTIEM lt
            INNER JOIN NGUOIDAN nd
                ON lt.MaNguoiDan = nd.MaNguoiDan
            INNER JOIN VACCINE v
                ON lt.MaVaccine = v.MaVaccine
            ORDER BY lt.NgayDuKien DESC
        `);

    return result.recordset;
};


// Tìm lịch theo ID
const findById = async (maLichTiem) => {
    const pool = await sql.connect();

    const result = await pool
        .request()
        .input(
            "MaLichTiem",
            sql.Int,
            maLichTiem
        )
        .query(`
            SELECT
                lt.MaLichTiem,
                lt.MaNguoiDan,
                nd.HoTen,
                lt.MaVaccine,
                v.TenVaccine,
                lt.MuiSo,
                lt.NgayDuKien,
                lt.CoSoTiem,
                lt.TrangThai,
                lt.GhiChu,
                lt.NgayTao,
                lt.MaNhanVienTao
            FROM LICHTIEM lt
            INNER JOIN NGUOIDAN nd
                ON lt.MaNguoiDan = nd.MaNguoiDan
            INNER JOIN VACCINE v
                ON lt.MaVaccine = v.MaVaccine
            WHERE lt.MaLichTiem = @MaLichTiem
        `);

    return result.recordset[0] || null;
};


// Lịch của một người dân
const findByCitizenId = async (maNguoiDan) => {
    const pool = await sql.connect();

    const result = await pool
        .request()
        .input(
            "MaNguoiDan",
            sql.Int,
            maNguoiDan
        )
        .query(`
            SELECT
                lt.MaLichTiem,
                lt.MaNguoiDan,
                v.TenVaccine,
                lt.MaVaccine,
                lt.MuiSo,
                lt.NgayDuKien,
                lt.CoSoTiem,
                lt.TrangThai,
                lt.GhiChu
            FROM LICHTIEM lt
            INNER JOIN VACCINE v
                ON lt.MaVaccine = v.MaVaccine
            WHERE lt.MaNguoiDan = @MaNguoiDan
            ORDER BY lt.NgayDuKien DESC
        `);

    return result.recordset;
};


// Tạo lịch tiêm
const create = async (
    data,
    maNhanVienTao
) => {
    const pool = await sql.connect();

    const result = await pool
        .request()

        .input(
            "MaNguoiDan",
            sql.Int,
            data.maNguoiDan
        )

        .input(
            "MaVaccine",
            sql.Int,
            data.maVaccine
        )

        .input(
            "MuiSo",
            sql.Int,
            data.muiSo
        )

        .input(
            "NgayDuKien",
            sql.DateTime2,
            new Date(data.ngayDuKien)
        )

        .input(
            "CoSoTiem",
            sql.NVarChar(255),
            data.coSoTiem || null
        )

        .input(
            "TrangThai",
            sql.NVarChar(50),
            "Đã lên lịch"
        )

        .input(
            "GhiChu",
            sql.NVarChar(500),
            data.ghiChu || null
        )

        .input(
            "MaNhanVienTao",
            sql.Int,
            maNhanVienTao
        )

        .query(`
            INSERT INTO LICHTIEM
            (
                MaNguoiDan,
                MaVaccine,
                MuiSo,
                NgayDuKien,
                CoSoTiem,
                TrangThai,
                GhiChu,
                MaNhanVienTao
            )
            OUTPUT INSERTED.*
            VALUES
            (
                @MaNguoiDan,
                @MaVaccine,
                @MuiSo,
                @NgayDuKien,
                @CoSoTiem,
                @TrangThai,
                @GhiChu,
                @MaNhanVienTao
            )
        `);

    return result.recordset[0];
};


// Cập nhật lịch
const update = async (
    maLichTiem,
    data
) => {
    const pool = await sql.connect();

    const result = await pool
        .request()

        .input(
            "MaLichTiem",
            sql.Int,
            maLichTiem
        )

        .input(
            "MaVaccine",
            sql.Int,
            data.maVaccine ?? null
        )

        .input(
            "MuiSo",
            sql.Int,
            data.muiSo ?? null
        )

        .input(
            "NgayDuKien",
            sql.DateTime2,
            data.ngayDuKien
                ? new Date(data.ngayDuKien)
                : null
        )

        .input(
            "CoSoTiem",
            sql.NVarChar(255),
            data.coSoTiem ?? null
        )

        .input(
            "GhiChu",
            sql.NVarChar(500),
            data.ghiChu ?? null
        )

        .query(`
            UPDATE LICHTIEM
            SET
                MaVaccine =
                    COALESCE(@MaVaccine, MaVaccine),

                MuiSo =
                    COALESCE(@MuiSo, MuiSo),

                NgayDuKien =
                    COALESCE(@NgayDuKien, NgayDuKien),

                CoSoTiem =
                    COALESCE(@CoSoTiem, CoSoTiem),

                GhiChu =
                    COALESCE(@GhiChu, GhiChu)

            WHERE MaLichTiem = @MaLichTiem;

            SELECT *
            FROM LICHTIEM
            WHERE MaLichTiem = @MaLichTiem;
        `);

    return result.recordset[0] || null;
};


// Cập nhật trạng thái lịch
const updateStatus = async (
    maLichTiem,
    trangThai
) => {
    const pool = await sql.connect();

    const result = await pool
        .request()

        .input(
            "MaLichTiem",
            sql.Int,
            maLichTiem
        )

        .input(
            "TrangThai",
            sql.NVarChar(50),
            trangThai
        )

        .query(`
            UPDATE LICHTIEM
            SET TrangThai = @TrangThai
            WHERE MaLichTiem = @MaLichTiem;

            SELECT *
            FROM LICHTIEM
            WHERE MaLichTiem = @MaLichTiem;
        `);

    return result.recordset[0] || null;
};
const createByCitizen = async (
    maNguoiDan,
    data
) => {
    const pool = await sql.connect();

    const result = await pool
        .request()
        .input(
            "MaNguoiDan",
            sql.Int,
            maNguoiDan
        )
        .input(
            "MaVaccine",
            sql.Int,
            data.maVaccine
        )
        .input(
            "MuiSo",
            sql.Int,
            data.muiSo
        )
        .input(
            "NgayDuKien",
            sql.DateTime2,
            data.ngayDuKien
        )
        .input(
            "CoSoTiem",
            sql.NVarChar(255),
            data.coSoTiem || null
        )
        .input(
            "TrangThai",
            sql.NVarChar(50),
            "Đã lên lịch"
        )
        .input(
            "GhiChu",
            sql.NVarChar(500),
            data.ghiChu || null
        )
        .query(`
            INSERT INTO LICHTIEM
            (
                MaNguoiDan,
                MaVaccine,
                MuiSo,
                NgayDuKien,
                CoSoTiem,
                TrangThai,
                GhiChu
            )
            OUTPUT INSERTED.MaLichTiem
            VALUES
            (
                @MaNguoiDan,
                @MaVaccine,
                @MuiSo,
                @NgayDuKien,
                @CoSoTiem,
                @TrangThai,
                @GhiChu
            )
        `);

    return result.recordset[0];
};

module.exports = {
    findAll,
    findById,
    findByCitizenId,
    create,
    update,
    updateStatus,
    createByCitizen
};