const express = require("express");
const cors = require("cors");

const { sql } =
    require("./config/database");

const authRoutes =
    require("./routes/authRoutes");
const citizenRoutes =
    require("./routes/citizenRoutes");
const vaccineRoutes =
    require("./routes/vaccineRoutes");
const batchRoutes =
    require("./routes/batchRoutes");
const scheduleRoutes =
    require("./routes/scheduleRoutes");
const vaccinationRoutes =
    require("./routes/vaccinationRoutes");
const contraindicationRoutes =
    require("./routes/contraindicationRoutes");
const historyRoutes =
    require("./routes/historyRoutes");
const traceRoutes =
    require("./routes/traceRoutes");
const notificationRoutes =
    require("./routes/notificationRoutes");
const userRoutes =
    require("./routes/userRoutes");
const app = express();


app.use(cors());

app.use(express.json());


app.get("/", (req, res) => {

    res.json({
        success: true,
        message:
            "API Cong theo doi tiem chung cong dong"
    });

});


app.get(
    "/api/test-database",
    async (req, res) => {

        try {

            const pool =
                await sql.connect();

            const result =
                await pool
                    .request()
                    .query(
                        "SELECT * FROM VAITRO"
                    );


            res.json({
                success: true,
                message:
                    "Ket noi database thanh cong",
                data:
                    result.recordset
            });

        } catch (error) {

            res.status(500).json({
                success: false,
                message:
                    "Loi database",
                error:
                    error.message
            });
        }
    }
);


// Authentication API
app.use(
    "/api/auth",
    authRoutes
);
app.use(
    "/api/citizens",
    citizenRoutes
);
app.use(
    "/api/vaccines",
    vaccineRoutes
);
app.use(
    "/api/batches",
    batchRoutes
);
app.use(
    "/api/schedules",
    scheduleRoutes
);
app.use(
    "/api/vaccinations",
    vaccinationRoutes
);
app.use(
    "/api/contraindications",
    contraindicationRoutes
);
app.use(
    "/api/history",
    historyRoutes
);
app.use(
    "/api/trace",
    traceRoutes
);
app.use(
    "/api/notifications",
    notificationRoutes
);
app.use(
    "/api/users",
    userRoutes
);
module.exports = app;