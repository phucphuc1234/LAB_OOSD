const sql = require("mssql");
require("dotenv").config();

const config = {
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    server: process.env.DB_SERVER,
    database: process.env.DB_DATABASE,
    port: parseInt(process.env.DB_PORT),

    options: {
        encrypt: false,
        trustServerCertificate: true
    }
};

const connectDB = async () => {
    try {
        const pool = await sql.connect(config);

        console.log("=================================");
        console.log("Ket noi SQL Server thanh cong!");
        console.log(`Database: ${process.env.DB_DATABASE}`);
        console.log("=================================");

        return pool;

    } catch (error) {
        console.error("Ket noi SQL Server that bai!");
        console.error(error.message);
        throw error;
    }
};

module.exports = {
    sql,
    connectDB
};