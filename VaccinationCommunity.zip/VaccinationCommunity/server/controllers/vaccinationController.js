const vaccinationService =
    require("../services/vaccinationService");


// GET /api/vaccinations/:id
const getVaccinationById = async (
    req,
    res
) => {

    try {

        const data =
            await vaccinationService
                .getVaccinationById(
                    req.params.id
                );

        res.json({
            success: true,
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


// POST /api/vaccinations
const createVaccination = async (
    req,
    res
) => {

    try {

        const data =
            await vaccinationService
                .createVaccination(
                    req.body,
                    req.user.maTaiKhoan
                );

        res.status(201).json({
            success: true,
            message:
                "Ghi nhận mũi tiêm thành công.",
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


module.exports = {
    getVaccinationById,
    createVaccination
};