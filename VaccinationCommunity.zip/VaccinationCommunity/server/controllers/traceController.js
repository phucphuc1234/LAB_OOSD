const traceService =
    require("../services/traceService");


// GET /api/trace/batch/:id
const traceBatchById = async (
    req,
    res
) => {

    try {

        const data =
            await traceService
                .traceBatchById(
                    req.params.id
                );

        res.json({
            success: true,
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message:
                    error.message
            });
    }
};


// GET /api/trace/batch-code/:code
const traceBatchByCode = async (
    req,
    res
) => {

    try {

        const data =
            await traceService
                .traceBatchByCode(
                    req.params.code
                );

        res.json({
            success: true,
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message:
                    error.message
            });
    }
};


// GET /api/trace/vaccination/:id
const traceVaccination = async (
    req,
    res
) => {

    try {

        const data =
            await traceService
                .traceVaccination(
                    req.params.id
                );

        res.json({
            success: true,
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message:
                    error.message
            });
    }
};


module.exports = {
    traceBatchById,
    traceBatchByCode,
    traceVaccination
};