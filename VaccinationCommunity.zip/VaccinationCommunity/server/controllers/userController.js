const userService =
    require("../services/userService");


const getAllUsers = async (
    req,
    res
) => {
    try {

        const data =
            await userService
                .getAllUsers();

        res.json({
            success: true,
            data
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};


const getUserById = async (
    req,
    res
) => {
    try {

        const data =
            await userService
                .getUserById(
                    req.params.id
                );

        res.json({
            success: true,
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


const changeStatus = async (
    req,
    res
) => {
    try {

        const data =
            await userService
                .changeStatus(
                    req.params.id,
                    req.body.trangThai,
                    req.user.maTaiKhoan
                );

        res.json({
            success: true,
            message:
                "Cập nhật trạng thái tài khoản thành công.",
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


const changeRole = async (
    req,
    res
) => {
    try {

        const data =
            await userService
                .changeRole(
                    req.params.id,
                    req.body.maVaiTro,
                    req.user.maTaiKhoan
                );

        res.json({
            success: true,
            message:
                "Phân quyền tài khoản thành công.",
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


module.exports = {
    getAllUsers,
    getUserById,
    changeStatus,
    changeRole
};