const vaccineService =
    require("../services/vaccineService");


// GET /api/vaccines
const getAllVaccines = async (
    req,
    res
) => {
    try {
        const data =
            await vaccineService
                .getAllVaccines();

        res.json({
            success: true,
            data
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};


// GET /api/vaccines/:id
const getVaccineById = async (
    req,
    res
) => {
    try {
        const data =
            await vaccineService
                .getVaccineById(
                    req.params.id
                );

        res.json({
            success: true,
            data
        });

    } catch (error) {
        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


// POST /api/vaccines
const createVaccine = async (
    req,
    res
) => {
    try {
        const data =
            await vaccineService
                .createVaccine(
                    req.body
                );

        res.status(201).json({
            success: true,
            message:
                "Thêm vaccine thành công.",
            data
        });

    } catch (error) {
        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


// PUT /api/vaccines/:id
const updateVaccine = async (
    req,
    res
) => {
    try {
        const data =
            await vaccineService
                .updateVaccine(
                    req.params.id,
                    req.body
                );

        res.json({
            success: true,
            message:
                "Cập nhật vaccine thành công.",
            data
        });

    } catch (error) {
        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


// PATCH /api/vaccines/:id/status
const changeStatus = async (
    req,
    res
) => {
    try {
        const data =
            await vaccineService
                .changeStatus(
                    req.params.id,
                    req.body.trangThai
                );

        res.json({
            success: true,
            message:
                "Cập nhật trạng thái vaccine thành công.",
            data
        });

    } catch (error) {
        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


module.exports = {
    getAllVaccines,
    getVaccineById,
    createVaccine,
    updateVaccine,
    changeStatus
};