const batchService =
    require("../services/batchService");


const getAllBatches = async (
    req,
    res
) => {
    try {

        const data =
            await batchService
                .getAllBatches();

        res.json({
            success: true,
            data
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};


const getBatchById = async (
    req,
    res
) => {
    try {

        const data =
            await batchService
                .getBatchById(
                    req.params.id
                );

        res.json({
            success: true,
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


const createBatch = async (
    req,
    res
) => {
    try {

        const data =
            await batchService
                .createBatch(
                    req.body
                );

        res.status(201).json({
            success: true,
            message:
                "Thêm lô vaccine thành công.",
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


const updateBatch = async (
    req,
    res
) => {
    try {

        const data =
            await batchService
                .updateBatch(
                    req.params.id,
                    req.body
                );

        res.json({
            success: true,
            message:
                "Cập nhật lô vaccine thành công.",
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


const changeStatus = async (
    req,
    res
) => {
    try {

        const data =
            await batchService
                .changeStatus(
                    req.params.id,
                    req.body.trangThai
                );

        res.json({
            success: true,
            message:
                "Cập nhật trạng thái lô vaccine thành công.",
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


module.exports = {
    getAllBatches,
    getBatchById,
    createBatch,
    updateBatch,
    changeStatus
};