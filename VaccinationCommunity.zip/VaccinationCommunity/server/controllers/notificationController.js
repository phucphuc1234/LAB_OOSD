const notificationService =
    require("../services/notificationService");


const getMyNotifications = async (
    req,
    res
) => {
    try {

        const data =
            await notificationService
                .getMyNotifications(
                    req.user.maTaiKhoan
                );

        res.json({
            success: true,
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


const markAsRead = async (
    req,
    res
) => {
    try {

        const data =
            await notificationService
                .markMyNotificationRead(
                    req.user.maTaiKhoan,
                    req.params.id
                );

        res.json({
            success: true,
            message:
                "Đã đánh dấu thông báo là đã đọc.",
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


const generateReminders = async (
    req,
    res
) => {
    try {

        const days =
            Number(req.body.daysAhead) || 3;

        const data =
            await notificationService
                .generateReminders(days);

        res.json({
            success: true,
            message:
                "Đã xử lý nhắc lịch tiêm.",
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


module.exports = {
    getMyNotifications,
    markAsRead,
    generateReminders
};