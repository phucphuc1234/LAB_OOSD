const contraindicationService =
    require(
        "../services/contraindicationService"
    );


const getAll = async (req, res) => {
    try {

        const data =
            await contraindicationService
                .getAll();

        res.json({
            success: true,
            data
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};


const getById = async (req, res) => {
    try {

        const data =
            await contraindicationService
                .getById(
                    req.params.id
                );

        res.json({
            success: true,
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


const getMyContraindications = async (
    req,
    res
) => {
    try {

        const data =
            await contraindicationService
                .getMyContraindications(
                    req.user.maTaiKhoan
                );

        res.json({
            success: true,
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


const createContraindication = async (
    req,
    res
) => {
    try {

        const data =
            await contraindicationService
                .createContraindication(
                    req.body,
                    req.user.maTaiKhoan
                );

        res.status(201).json({
            success: true,
            message:
                "Ghi nhận chống chỉ định thành công.",
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


const updateContraindication = async (
    req,
    res
) => {
    try {

        const data =
            await contraindicationService
                .updateContraindication(
                    req.params.id,
                    req.body,
                    req.user.maTaiKhoan
                );

        res.json({
            success: true,
            message:
                "Cập nhật chống chỉ định thành công.",
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


module.exports = {
    getAll,
    getById,
    getMyContraindications,
    createContraindication,
    updateContraindication
};