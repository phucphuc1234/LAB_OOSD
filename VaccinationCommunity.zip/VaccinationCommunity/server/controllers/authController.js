const authService =
    require("../services/authService");


const register = async (req, res) => {

    try {

        const result =
            await authService.register(req.body);

        res.status(201).json({
            success: true,
            ...result
        });

    } catch (error) {

        res
            .status(error.statusCode || 500)
            .json({
                success: false,
                message:
                    error.message ||
                    "Lỗi hệ thống."
            });
    }
};


const login = async (req, res) => {

    try {

        const {
            tenDangNhap,
            matKhau
        } = req.body;


        const result =
            await authService.login(
                tenDangNhap,
                matKhau
            );


        res.json({
            success: true,
            message: "Đăng nhập thành công.",
            ...result
        });

    } catch (error) {

        res
            .status(error.statusCode || 500)
            .json({
                success: false,
                message:
                    error.message ||
                    "Lỗi hệ thống."
            });
    }
};


const logout = async (req, res) => {

    res.json({
        success: true,
        message: "Đăng xuất thành công."
    });
};

const changePassword = async (
    req,
    res
) => {
    try {

        const {
            matKhauHienTai,
            matKhauMoi
        } = req.body;


        const result =
            await authService
                .changePassword(
                    req.user.maTaiKhoan,
                    matKhauHienTai,
                    matKhauMoi
                );


        res.json({
            success: true,
            message: result.message
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 400
            )
            .json({
                success: false,
                message: error.message
            });
    }
};
module.exports = {
    register,
    login,
    logout,
    changePassword
};