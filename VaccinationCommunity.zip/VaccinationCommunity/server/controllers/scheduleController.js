const scheduleService =
    require("../services/scheduleService");


const getAllSchedules = async (
    req,
    res
) => {
    try {

        const data =
            await scheduleService
                .getAllSchedules();

        res.json({
            success: true,
            data
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};


const getScheduleById = async (
    req,
    res
) => {
    try {

        const data =
            await scheduleService
                .getScheduleById(
                    req.params.id
                );

        res.json({
            success: true,
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


const getMySchedules = async (
    req,
    res
) => {
    try {

        const data =
            await scheduleService
                .getMySchedules(
                    req.user.maTaiKhoan
                );

        res.json({
            success: true,
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


const createSchedule = async (
    req,
    res
) => {
    try {

        const data =
            await scheduleService
                .createSchedule(
                    req.body,
                    req.user.maTaiKhoan
                );

        res.status(201).json({
            success: true,
            message:
                "Tạo lịch tiêm thành công.",
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


const updateSchedule = async (
    req,
    res
) => {
    try {

        const data =
            await scheduleService
                .updateSchedule(
                    req.params.id,
                    req.body
                );

        res.json({
            success: true,
            message:
                "Cập nhật lịch tiêm thành công.",
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


const changeStatus = async (
    req,
    res
) => {
    try {

        const data =
            await scheduleService
                .changeStatus(
                    req.params.id,
                    req.body.trangThai
                );

        res.json({
            success: true,
            message:
                "Cập nhật trạng thái lịch tiêm thành công.",
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};
const createMySchedule = async (
    req,
    res
) => {
    try {

        const result =
            await scheduleService
                .createMySchedule(
                    req.user.maTaiKhoan,
                    req.body
                );


        res.status(201).json({
            success: true,
            message:
                result.message,
            data: {
                maLichTiem:
                    result.maLichTiem
            }
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 400
            )
            .json({
                success: false,
                message:
                    error.message
            });
    }
};

module.exports = {
    getAllSchedules,
    getScheduleById,
    getMySchedules,
    createSchedule,
    updateSchedule,
    changeStatus,
    createMySchedule
};