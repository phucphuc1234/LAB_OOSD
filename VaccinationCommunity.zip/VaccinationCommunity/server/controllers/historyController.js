const historyService =
    require("../services/historyService");


// GET /api/history/me
const getMyHistory = async (
    req,
    res
) => {
    try {

        const data =
            await historyService
                .getMyHistory(
                    req.user.maTaiKhoan
                );

        res.json({
            success: true,
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


// GET /api/history/citizen/:id
const getCitizenHistory = async (
    req,
    res
) => {
    try {

        const data =
            await historyService
                .getCitizenHistory(
                    req.params.id
                );

        res.json({
            success: true,
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


// GET /api/history/detail/:id
const getHistoryDetail = async (
    req,
    res
) => {
    try {

        const data =
            await historyService
                .getHistoryDetail(
                    req.params.id
                );

        res.json({
            success: true,
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


// GET /api/history/me/:id
const getMyHistoryDetail = async (
    req,
    res
) => {
    try {

        const data =
            await historyService
                .getMyHistoryDetail(
                    req.user.maTaiKhoan,
                    req.params.id
                );

        res.json({
            success: true,
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message: error.message
            });
    }
};


module.exports = {
    getMyHistory,
    getCitizenHistory,
    getHistoryDetail,
    getMyHistoryDetail
};