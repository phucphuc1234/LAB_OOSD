const citizenService =
    require("../services/citizenService");


// GET /api/citizens/me
const getMyProfile = async (
    req,
    res
) => {

    try {

        const data =
            await citizenService
                .getMyProfile(
                    req.user.maTaiKhoan
                );

        res.json({
            success: true,
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message:
                    error.message
            });
    }
};


// PUT /api/citizens/me
const updateMyProfile = async (
    req,
    res
) => {

    try {

        const data =
            await citizenService
                .updateMyProfile(
                    req.user.maTaiKhoan,
                    req.body
                );

        res.json({
            success: true,
            message:
                "Cập nhật hồ sơ thành công.",
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message:
                    error.message
            });
    }
};


// GET /api/citizens
const getAllCitizens = async (
    req,
    res
) => {

    try {

        const data =
            await citizenService
                .getAllCitizens();

        res.json({
            success: true,
            data
        });

    } catch (error) {

        res.status(500).json({
            success: false,
            message:
                error.message
        });
    }
};


// GET /api/citizens/:id
const getCitizenById = async (
    req,
    res
) => {

    try {

        const data =
            await citizenService
                .getCitizenById(
                    req.params.id
                );

        res.json({
            success: true,
            data
        });

    } catch (error) {

        res
            .status(
                error.statusCode || 500
            )
            .json({
                success: false,
                message:
                    error.message
            });
    }
};


module.exports = {
    getMyProfile,
    updateMyProfile,
    getAllCitizens,
    getCitizenById
};