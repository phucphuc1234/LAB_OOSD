require("dotenv").config();

const app = require("./app");

const {
    connectDB
} = require("./config/database");

const notificationService =
    require("./services/notificationService");


const PORT =
    process.env.PORT || 5000;


// =====================================
// JOB TỰ ĐỘNG NHẮC LỊCH TIÊM
// =====================================

const runReminderJob = async () => {

    try {

        const result =
            await notificationService
                .generateReminders(3);


        console.log(
            `[REMINDER] Da kiem tra: ${result.checked}` +
            ` | Tao moi: ${result.created}`
        );

    } catch (error) {

        console.error(
            "[REMINDER] Loi tao thong bao:"
        );

        console.error(
            error.message
        );

    }

};


// =====================================
// KHỞI ĐỘNG SERVER
// =====================================

const startServer = async () => {

    try {

        // Kết nối SQL Server
        await connectDB();


        // Khởi động API
        app.listen(
            PORT,
            () => {

                console.log(
                    `Server dang chay tai http://localhost:${PORT}`
                );

            }
        );


        // =====================================
        // CHẠY NHẮC LỊCH NGAY KHI SERVER BẬT
        // =====================================

        await runReminderJob();


        // =====================================
        // SAU ĐÓ KIỂM TRA LẠI MỖI 1 GIỜ
        // =====================================

        setInterval(
            () => {

                runReminderJob();

            },

            60 * 60 * 1000
        );


    } catch (error) {

        console.error(
            "Khong the khoi dong server."
        );

        console.error(
            error.message
        );


        process.exit(1);

    }

};


startServer();