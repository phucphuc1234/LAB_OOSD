const express = require("express");

const scheduleController =
    require("../controllers/scheduleController");

const authenticate =
    require("../middlewares/authMiddleware");

const authorizeRoles =
    require("../middlewares/roleMiddleware");


const router = express.Router();


router.use(authenticate);


// Người dân xem lịch của chính mình
router.get(
    "/me",
    authorizeRoles("Người dân"),
    scheduleController.getMySchedules
);
router.post(
    "/me",
    authorizeRoles("Người dân"),
    scheduleController.createMySchedule
);

// Nhân viên xem tất cả lịch
router.get(
    "/",
    authorizeRoles("Nhân viên"),
    scheduleController.getAllSchedules
);


// Nhân viên xem chi tiết
router.get(
    "/:id",
    authorizeRoles("Nhân viên"),
    scheduleController.getScheduleById
);


// Nhân viên lập lịch
router.post(
    "/",
    authorizeRoles("Nhân viên"),
    scheduleController.createSchedule
);


// Nhân viên sửa lịch
router.put(
    "/:id",
    authorizeRoles("Nhân viên"),
    scheduleController.updateSchedule
);


// Nhân viên đổi trạng thái
router.patch(
    "/:id/status",
    authorizeRoles("Nhân viên"),
    scheduleController.changeStatus
);


module.exports = router;